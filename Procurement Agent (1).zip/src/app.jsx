// Main App
function App() {
  const [lang, setLang] = React.useState(() => localStorage.getItem('aib-lang') || 'en');
  const [ccy, setCcy] = React.useState(() => localStorage.getItem('aib-ccy') || 'IDR');
  const [theme, setTheme] = React.useState(() => localStorage.getItem('aib-theme') || 'light');
  const [page, setPage] = React.useState(() => localStorage.getItem('aib-page') || 'inbox');
  const [copilotOpen, setCopilotOpen] = React.useState(false);
  const [density, setDensity] = React.useState('comfy');
  const [copilotDock, setCopilotDock] = React.useState('fab');
  const [tweaksOpen, setTweaksOpen] = React.useState(false);
  const [cmdkOpen, setCmdkOpen] = React.useState(false);
  const [plain, setPlain] = React.useState(false);

  React.useEffect(() => { document.documentElement.dataset.theme = theme; localStorage.setItem('aib-theme', theme); }, [theme]);
  React.useEffect(() => { localStorage.setItem('aib-lang', lang); }, [lang]);
  React.useEffect(() => { localStorage.setItem('aib-ccy', ccy); }, [ccy]);
  React.useEffect(() => { localStorage.setItem('aib-page', page); }, [page]);

  // Cmd+K shortcut
  React.useEffect(() => {
    const h = (e) => {
      if ((e.metaKey || e.ctrlKey) && e.key === 'k') { e.preventDefault(); setCmdkOpen(o => !o); }
    };
    window.addEventListener('keydown', h);
    return () => window.removeEventListener('keydown', h);
  }, []);

  // Tweaks host integration
  React.useEffect(() => {
    const handler = (e) => {
      if (!e.data || typeof e.data !== 'object') return;
      if (e.data.type === '__activate_edit_mode') setTweaksOpen(true);
      if (e.data.type === '__deactivate_edit_mode') setTweaksOpen(false);
    };
    window.addEventListener('message', handler);
    window.parent.postMessage({ type: '__edit_mode_available' }, '*');
    return () => window.removeEventListener('message', handler);
  }, []);

  const t = useT(lang);
  const openVendor = () => setPage('vendor360');
  const openWizard = () => setPage('rfqWizard');
  const pageMap = {
    inbox: { label: t('nav_inbox'), render: <InboxPage lang={lang} ccy={ccy} openVendor={openVendor} /> },
    agents: { label: t('nav_agents'), render: <AgentsPage lang={lang} /> },
    dashboard: { label: t('nav_dashboard'), render: <DashboardPage lang={lang} ccy={ccy} /> },
    rfq: { label: t('nav_sourcing'), render: <RfqPage lang={lang} ccy={ccy} /> },
    rfqWizard: { label: 'New RFQ', render: <RfqWizardPage lang={lang} ccy={ccy} onClose={() => setPage('rfq')} /> },
    vendor360: { label: 'Vendor · PT Kemasan Jaya Abadi', render: <Vendor360Page lang={lang} ccy={ccy} back={() => setPage('vendors')} /> },
    spend: { label: t('nav_spend'), render: <SpendPage lang={lang} ccy={ccy} /> },
    categorize: { label: t('nav_categorize'), render: <CategorizePage lang={lang} ccy={ccy} /> },
    savings: { label: t('nav_savings'), render: <SavingsPage lang={lang} ccy={ccy} /> },
    kpi: { label: t('nav_kpi'), render: <KpiPage lang={lang} ccy={ccy} /> },
    vendors: { label: t('nav_vendors'), render: <VendorsStubPage lang={lang} openVendor={openVendor} /> },
  };
  // Placeholder pages for sidebar entries we haven't fleshed out
  const placeholder = (label) => ({
    label,
    render: (
      <div className="page">
        <div className="page-head">
          <div>
            <div className="page-title">{label}</div>
            <div className="page-sub">This surface is out of scope for the first design cut.</div>
          </div>
        </div>
        <div className="card" style={{ padding: 60, textAlign: 'center' }}>
          <div style={{ fontSize: 13, color: 'var(--text-3)', maxWidth: 420, margin: '0 auto' }}>
            The control-tower brief focused on Dashboard, Sourcing (RFQ), Spend Analysis, AI Categorization, Savings, and KPI/Governance. This module is reachable from the nav but left as a stub for now.
          </div>
        </div>
      </div>
    ),
  });
  const resolved = pageMap[page] || placeholder(t('nav_' + page));

  return (
    <div className={'app ' + (density === 'compact' ? 'compact' : '') + (plain ? ' plain' : '')}>
      <Sidebar lang={lang} page={page} setPage={setPage} />
      <div className="main">
        <Topbar lang={lang} setLang={setLang} ccy={ccy} setCcy={setCcy} theme={theme} setTheme={setTheme}
                openCopilot={() => setCopilotOpen(true)}
                openCmdk={() => setCmdkOpen(true)}
                openWizard={openWizard}
                plain={plain} setPlain={setPlain}
                pageLabel={resolved.label} />
        {resolved.render}
      </div>

      <CommandBar open={cmdkOpen} onClose={() => setCmdkOpen(false)} setPage={setPage} openWizard={openWizard} openVendor={openVendor} />

      {copilotDock === 'fab' && !copilotOpen && (
        <button className="copilot-fab" onClick={() => setCopilotOpen(true)}>
          <span className="glow"></span>
          {Icons.sparkle}
          {t('copilot')}
        </button>
      )}
      <Copilot open={copilotOpen} onClose={() => setCopilotOpen(false)} lang={lang} />

      {tweaksOpen && (
        <TweaksPanel
          theme={theme} setTheme={setTheme}
          density={density} setDensity={setDensity}
          copilotDock={copilotDock} setCopilotDock={setCopilotDock}
          plain={plain} setPlain={setPlain}
          onClose={() => setTweaksOpen(false)}
        />
      )}
    </div>
  );
}

// Small stub listing a few vendors so the Vendor 360 entry works via nav too
function VendorsStubPage({ lang, openVendor }) {
  const rows = [
    { name: 'PT Kemasan Jaya Abadi', cat: 'Packaging & Labels', tier: 'Strategic', otif: 96, spend: '8.2 M' },
    { name: 'PT Indoprint Solusi', cat: 'Packaging & Labels', tier: 'Preferred', otif: 82, spend: '3.4 M' },
    { name: 'CV Grafika Mandiri', cat: 'Packaging & Labels', tier: 'Preferred', otif: 94, spend: '2.1 M' },
    { name: 'PT Logistik Nusantara', cat: 'Logistics', tier: 'Strategic', otif: 91, spend: '5.8 M' },
    { name: 'PT Cahaya Teknologi', cat: 'IT', tier: 'Preferred', otif: 98, spend: '1.9 M' },
  ];
  return (
    <div className="page">
      <div className="page-head">
        <div><div className="page-title">Vendors</div><div className="page-sub">318 active vendors · click for Vendor 360</div></div>
        <button className="btn primary">{Icons.plus}Onboard vendor</button>
      </div>
      <div className="card">
        <div style={{ padding: 0 }}>
          <table className="tbl">
            <thead><tr><th>Vendor</th><th>Category</th><th>Tier</th><th>OTIF</th><th>YTD spend</th><th></th></tr></thead>
            <tbody>
              {rows.map(r => (
                <tr key={r.name} onClick={r.name === 'PT Kemasan Jaya Abadi' ? openVendor : undefined}
                    style={r.name === 'PT Kemasan Jaya Abadi' ? { cursor: 'pointer' } : {}}>
                  <td style={{ fontWeight: 600 }}>{r.name}</td>
                  <td>{r.cat}</td>
                  <td><span className={'tag ' + (r.tier === 'Strategic' ? 'brand' : '')}>{r.tier}</span></td>
                  <td className="num">{r.otif}%</td>
                  <td className="num">Rp {r.spend}</td>
                  <td>{r.name === 'PT Kemasan Jaya Abadi' && <span className="tag brand">Open 360 →</span>}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}

ReactDOM.createRoot(document.getElementById('root')).render(<App />);
