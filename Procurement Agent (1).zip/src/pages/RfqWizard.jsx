// Create RFQ Wizard
function RfqWizardPage({ lang, ccy, onClose }) {
  const t = useT(lang);
  const [step, setStep] = React.useState(0);
  const [title, setTitle] = React.useState('Packaging & store supplies — Q3 refill');
  const [cat, setCat] = React.useState('Packaging & Labels');
  const [vendors, setVendors] = React.useState([true, true, true, true, false]);

  const steps = ['Details', 'AI suggest', 'Line items', 'Vendors', 'Review'];

  return (
    <div className="page">
      <div className="page-head">
        <div>
          <div className="row" style={{ gap: 8, marginBottom: 4 }}>
            <span className="tag brand">New RFQ</span>
            <span className="tag"><span className="ai-dot" style={{ background: 'var(--brand)' }}></span>AI-assisted</span>
          </div>
          <div className="page-title">Create Request for Quote</div>
          <div className="page-sub">5-step guided flow · AI pre-fills vendors, prices and line items from your history.</div>
        </div>
        <button className="btn ghost" onClick={onClose}>Cancel</button>
      </div>

      <div className="wiz-steps">
        {steps.map((s, i) => (
          <div key={s} className={'wiz-step ' + (i < step ? 'done ' : '') + (i === step ? 'current' : '')} onClick={() => setStep(i)}>
            <span className="num">{i < step ? '✓' : i + 1}</span>
            <span>{s}</span>
          </div>
        ))}
      </div>

      {step === 0 && (
        <div className="card">
          <div className="card-body" style={{ padding: 22, display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 18 }}>
            <div style={{ gridColumn: '1 / -1' }}>
              <label className="field-label">RFQ title</label>
              <input className="field" value={title} onChange={e => setTitle(e.target.value)} />
            </div>
            <div>
              <label className="field-label">Category</label>
              <select className="field" value={cat} onChange={e => setCat(e.target.value)}>
                <option>Packaging & Labels</option>
                <option>Logistics & Freight</option>
                <option>IT & Software</option>
                <option>Store Maintenance</option>
              </select>
            </div>
            <div>
              <label className="field-label">Business unit</label>
              <select className="field"><option>Retail Ops — West</option><option>Retail Ops — East</option></select>
            </div>
            <div>
              <label className="field-label">Requester</label>
              <input className="field" defaultValue="Maya Handoko" />
            </div>
            <div>
              <label className="field-label">Budget (IDR)</label>
              <input className="field" defaultValue="1,850,000,000" />
            </div>
            <div>
              <label className="field-label">Needed by</label>
              <input className="field" type="date" defaultValue="2026-06-15" />
            </div>
            <div>
              <label className="field-label">Bid deadline</label>
              <input className="field" type="date" defaultValue="2026-05-08" />
            </div>
          </div>
        </div>
      )}

      {step === 1 && (
        <div className="grid" style={{ gridTemplateColumns: '1fr 1fr', gap: 14 }}>
          <div className="ai-hint" style={{ gridColumn: '1 / -1' }}>
            <div className="ai-ic">AI</div>
            <div style={{ flex: 1 }}>
              <strong style={{ color: 'var(--text)' }}>I've drafted this RFQ based on your last 3 quarterly refills</strong>
              <div style={{ color: 'var(--text-2)', fontSize: 12.5, marginTop: 3 }}>
                Review the suggested scope, line items and vendors. You can edit or remove any item before sending.
              </div>
            </div>
            <span className="tag brand">{t('confidence')} 91%</span>
          </div>
          {[
            { title: 'Scope & requirements', body: 'Kraft shopping bags (L, M), produce wrap film, price labels, corrugated boxes S — quantities match Q2 plan +8% for new outlets.' },
            { title: 'Expected price range', body: 'Rp 1.65 – 1.83 M based on last 3 quoted cycles. Target mid-range ≈ Rp 1.74 M.' },
            { title: 'Suggested vendors (5)', body: '2 strategic, 2 preferred, 1 new qualified match — optimized for price + lead time balance.' },
            { title: 'Policy checks', body: 'Requires 3 bidders for amounts > Rp 500 jt ✓. FSC certification required ✓. Budget owner approval needed.' },
          ].map((c, i) => (
            <div key={i} className="card" style={{ padding: 16 }}>
              <div style={{ display: 'flex', alignItems: 'start', gap: 10 }}>
                <div style={{ width: 26, height: 26, borderRadius: 6, background: 'var(--brand)', color: 'white', display: 'grid', placeItems: 'center', fontSize: 11, fontWeight: 700 }}>AI</div>
                <div style={{ flex: 1 }}>
                  <div style={{ fontWeight: 650, fontSize: 14, marginBottom: 4 }}>{c.title}</div>
                  <div style={{ fontSize: 12.5, color: 'var(--text-2)', lineHeight: 1.5 }}>{c.body}</div>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      {step === 2 && (
        <div className="card">
          <div className="card-head">
            <div className="card-title">Line items · 5</div>
            <div className="row"><button className="btn sm">{Icons.plus}Add item</button><button className="btn sm">{Icons.sparkle}AI add more</button></div>
          </div>
          <div style={{ padding: 0 }}>
            <table className="tbl">
              <thead><tr><th>SKU</th><th>Description</th><th>Qty</th><th>Last unit price</th><th>Spec</th><th></th></tr></thead>
              <tbody>
                {[
                  { sku: 'PCK-BAG-L', name: 'Shopping bag L (kraft, 30×40cm)', qty: 480_000, last: 1_280 },
                  { sku: 'PCK-BAG-M', name: 'Shopping bag M (kraft, 25×32cm)', qty: 620_000, last: 980 },
                  { sku: 'PCK-WRAP', name: 'Produce wrap film 45cm × 300m', qty: 2_400, last: 42_500 },
                  { sku: 'LBL-PRC', name: 'Price label roll (thermal, 35×25mm)', qty: 18_000, last: 18_200 },
                  { sku: 'PCK-BOX-S', name: 'Corrugated box S (double-wall)', qty: 92_000, last: 3_650 },
                ].map(r => (
                  <tr key={r.sku}>
                    <td className="mono" style={{ fontWeight: 600 }}>{r.sku}</td>
                    <td>{r.name}</td>
                    <td className="num">{fmtNum(r.qty)}</td>
                    <td className="num">{fmtMoney(r.last, ccy, { compact: false })}</td>
                    <td><span className="tag">attached</span></td>
                    <td><button className="btn ghost sm">{Icons.more}</button></td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {step === 3 && (
        <div className="card">
          <div className="card-head">
            <div>
              <div className="card-title">Invite vendors</div>
              <div className="card-sub">AI shortlisted 5 based on history, OTIF and category fit</div>
            </div>
            <span className="tag brand"><span className="ai-dot"></span>AI ranked</span>
          </div>
          <div style={{ padding: 0 }}>
            {DATA.rfqWizard.suggestedVendors.map((v, i) => (
              <div key={v.name} style={{
                padding: '14px 18px',
                borderBottom: i < DATA.rfqWizard.suggestedVendors.length - 1 ? '1px solid var(--border)' : '0',
                display: 'grid', gridTemplateColumns: '24px 1fr 100px 140px 80px',
                gap: 14, alignItems: 'center'
              }}>
                <input type="checkbox" checked={vendors[i]} onChange={() => setVendors(vs => vs.map((x, idx) => idx === i ? !x : x))} />
                <div>
                  <div style={{ fontWeight: 600 }}>{v.name}</div>
                  <div style={{ fontSize: 11.5, color: 'var(--text-3)', marginTop: 2 }}>
                    OTIF {v.otif}% · {v.lastPrice ? `last quoted ${fmtMoney(v.lastPrice, ccy, { compact: true })}` : 'no prior history'}
                  </div>
                </div>
                <span className={'tag ' + (v.tag === 'Strategic' ? 'brand' : v.tag === 'New match' ? 'warn' : '')}>{v.tag}</span>
                <div className="prog"><span style={{ width: `${v.otif}%`, background: v.otif >= 92 ? 'var(--pos)' : 'var(--warn)' }}></span></div>
                <div className="mono num" style={{ fontSize: 12 }}>{v.otif}%</div>
              </div>
            ))}
          </div>
        </div>
      )}

      {step === 4 && (
        <div className="card">
          <div className="card-body">
            <div style={{ fontSize: 18, fontWeight: 650, marginBottom: 14 }}>Ready to send</div>
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 14, marginBottom: 20 }}>
              <div><div className="field-label">Title</div><div>{title}</div></div>
              <div><div className="field-label">Category</div><div>{cat}</div></div>
              <div><div className="field-label">Line items</div><div>5 items · 1.2M units</div></div>
              <div><div className="field-label">Vendors</div><div>{vendors.filter(Boolean).length} invited</div></div>
              <div><div className="field-label">Budget</div><div>Rp 1.85 M</div></div>
              <div><div className="field-label">Bid deadline</div><div>8 May 2026</div></div>
              <div><div className="field-label">Policy</div><div><span className="tag pos">✓ Compliant</span></div></div>
              <div><div className="field-label">Approval</div><div>Head of Procurement</div></div>
            </div>
            <div className="ai-hint">
              <div className="ai-ic">AI</div>
              <div style={{ flex: 1 }}>
                <strong style={{ color: 'var(--text)' }}>Forecast</strong>: This RFQ should close within 12 days with an expected winning bid of <b>Rp 1.71 – 1.76 M</b> — saving Rp 110–190 jt vs last year.
              </div>
            </div>
          </div>
        </div>
      )}

      <div className="row" style={{ marginTop: 16, justifyContent: 'space-between' }}>
        <button className="btn" disabled={step === 0} onClick={() => setStep(s => Math.max(0, s - 1))}>← Previous</button>
        <div className="row">
          <button className="btn ghost">Save draft</button>
          {step < steps.length - 1
            ? <button className="btn primary" onClick={() => setStep(s => Math.min(steps.length - 1, s + 1))}>Next →</button>
            : <button className="btn primary">{Icons.send}Send to vendors</button>}
        </div>
      </div>
    </div>
  );
}

window.RfqWizardPage = RfqWizardPage;
