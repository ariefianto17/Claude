// Savings Opportunities page
function SavingsPage({ lang, ccy }) {
  const t = useT(lang);
  const total = DATA.savings.reduce((s, o) => s + o.potential, 0);
  const [sel, setSel] = React.useState(0);
  const o = DATA.savings[sel];

  const leverColor = {
    lever_consolidation: 'var(--brand)',
    lever_negotiation: 'oklch(0.62 0.13 195)',
    lever_substitution: 'oklch(0.68 0.12 160)',
    lever_tail: 'oklch(0.72 0.12 90)',
    lever_payment: 'oklch(0.70 0.13 30)',
  };

  return (
    <div className="page">
      <div className="page-head">
        <div>
          <div className="page-title">{t('sav_title')}</div>
          <div className="page-sub">{t('sav_sub')}</div>
        </div>
        <div className="row">
          <button className="btn">{Icons.filter}{t('filter')}</button>
          <button className="btn primary">{Icons.sparkle}Run scan</button>
        </div>
      </div>

      <div className="grid" style={{ gridTemplateColumns: 'repeat(4, 1fr)', marginBottom: 16 }}>
        <div className="kpi">
          <div className="label">{t('potential')}</div>
          <div className="val" style={{ color: 'var(--pos)' }}>{fmtMoney(total, ccy, { compact: true })}</div>
          <div className="sub"><span className="delta up">4.7%</span> of YTD spend</div>
        </div>
        <div className="kpi">
          <div className="label">{t('opportunities_open')}</div>
          <div className="val">{DATA.savings.length}</div>
          <div className="sub">across 5 levers</div>
        </div>
        <div className="kpi">
          <div className="label">{t('realized_ytd')}</div>
          <div className="val">{fmtMoney(DATA.kpis.savings_realized_idr, ccy, { compact: true })}</div>
          <div className="sub"><span className="delta up">18.6%</span> vs plan</div>
        </div>
        <div className="kpi">
          <div className="label">Avg. confidence</div>
          <div className="val">77%</div>
          <div className="sub">AI-weighted</div>
        </div>
      </div>

      {/* Effort-impact matrix + list */}
      <div className="grid" style={{ gridTemplateColumns: '1fr 1.3fr', marginBottom: 16 }}>
        <div className="card">
          <div className="card-head">
            <div>
              <div className="card-title">Effort vs. impact</div>
              <div className="card-sub">Prioritize high-impact / low-effort</div>
            </div>
          </div>
          <div className="card-body">
            <svg viewBox="0 0 320 280" width="100%" style={{ display: 'block' }}>
              {/* Quadrant bg */}
              <rect x="40" y="20" width="260" height="220" fill="var(--surface-2)" rx="8" />
              <line x1="170" y1="20" x2="170" y2="240" stroke="var(--border)" strokeDasharray="3 3" />
              <line x1="40" y1="130" x2="300" y2="130" stroke="var(--border)" strokeDasharray="3 3" />
              {/* Quadrant labels */}
              <text x="105" y="35" textAnchor="middle" fontSize="9.5" fill="var(--text-3)" fontFamily="var(--font-mono)" letterSpacing="0.05em">QUICK WINS</text>
              <text x="235" y="35" textAnchor="middle" fontSize="9.5" fill="var(--text-3)" fontFamily="var(--font-mono)" letterSpacing="0.05em">STRATEGIC</text>
              <text x="105" y="235" textAnchor="middle" fontSize="9.5" fill="var(--text-3)" fontFamily="var(--font-mono)" letterSpacing="0.05em">FILL-INS</text>
              <text x="235" y="235" textAnchor="middle" fontSize="9.5" fill="var(--text-3)" fontFamily="var(--font-mono)" letterSpacing="0.05em">MAJOR</text>
              {/* Axes labels */}
              <text x="170" y="260" textAnchor="middle" fontSize="11" fill="var(--text-3)" fontWeight="600">Effort →</text>
              <text x="14" y="130" transform="rotate(-90 14 130)" textAnchor="middle" fontSize="11" fill="var(--text-3)" fontWeight="600">Impact →</text>
              {/* Bubbles */}
              {DATA.savings.map((s, i) => {
                const ex = { Low: 90, Medium: 170, High: 250 }[s.effort];
                const impactY = s.impact === 'High' ? 75 : s.impact === 'Medium' ? 155 : 215;
                const rSize = Math.max(8, Math.min(28, s.potential / 20_000_000));
                const color = leverColor[s.lever];
                return (
                  <g key={i} style={{ cursor: 'pointer' }} onClick={() => setSel(i)} opacity={sel === i ? 1 : 0.75}>
                    <circle cx={ex} cy={impactY} r={rSize} fill={color} fillOpacity="0.25" stroke={color} strokeWidth={sel === i ? 2.5 : 1.5} />
                    <text x={ex} y={impactY + 3} textAnchor="middle" fontSize="10" fontWeight="700" fill={color}>{i + 1}</text>
                  </g>
                );
              })}
            </svg>
          </div>
        </div>

        <div className="card">
          <div className="card-head">
            <div className="card-title">Opportunity detail</div>
            <span className="tag brand"><span className="ai-dot"></span>AI</span>
          </div>
          <div className="card-body">
            <div className="row" style={{ gap: 10, marginBottom: 12 }}>
              <span className="tag" style={{ background: leverColor[o.lever], color: 'white', borderColor: 'transparent' }}>
                #{sel + 1} {t(o.lever)}
              </span>
              <span className="tag pos">Potential {fmtMoney(o.potential, ccy, { compact: true })}</span>
              <span className="tag">{t('confidence')} {o.confidence}%</span>
            </div>
            <div style={{ fontSize: 18, fontWeight: 650, letterSpacing: '-0.01em', marginBottom: 8 }}>{o.title}</div>
            <div style={{ color: 'var(--text-2)', fontSize: 13.5, lineHeight: 1.6 }}>{o.detail}</div>

            <div className="divider"></div>

            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 14 }}>
              <div>
                <div style={{ fontSize: 10.5, textTransform: 'uppercase', letterSpacing: '0.06em', color: 'var(--text-3)', fontWeight: 600 }}>Effort</div>
                <div style={{ fontWeight: 650, marginTop: 3 }}>{o.effort}</div>
              </div>
              <div>
                <div style={{ fontSize: 10.5, textTransform: 'uppercase', letterSpacing: '0.06em', color: 'var(--text-3)', fontWeight: 600 }}>Impact</div>
                <div style={{ fontWeight: 650, marginTop: 3 }}>{o.impact}</div>
              </div>
              <div>
                <div style={{ fontSize: 10.5, textTransform: 'uppercase', letterSpacing: '0.06em', color: 'var(--text-3)', fontWeight: 600 }}>Timeline</div>
                <div style={{ fontWeight: 650, marginTop: 3 }}>4–6 weeks</div>
              </div>
            </div>

            <div className="divider"></div>

            <div className="row">
              <button className="btn ghost sm">{t('dismiss')}</button>
              <div className="spacer"></div>
              <button className="btn sm">{t('assign')}</button>
              <button className="btn sm primary">{Icons.check}Approve plan</button>
            </div>
          </div>
        </div>
      </div>

      <div className="card">
        <div className="card-head">
          <div className="card-title">All opportunities</div>
          <div className="seg">
            <button className="on">All</button>
            <button>Open</button>
            <button>In progress</button>
            <button>Realized</button>
          </div>
        </div>
        <div style={{ padding: 0 }}>
          <table className="tbl">
            <thead>
              <tr>
                <th style={{ width: 28 }}>#</th>
                <th>Opportunity</th>
                <th>Lever</th>
                <th>Potential</th>
                <th>{t('confidence')}</th>
                <th>{t('effort')} / {t('impact')}</th>
                <th></th>
              </tr>
            </thead>
            <tbody>
              {DATA.savings.map((s, i) => (
                <tr key={i} style={{ background: sel === i ? 'var(--surface-2)' : undefined }} onClick={() => setSel(i)}>
                  <td className="mono num" style={{ color: 'var(--text-3)' }}>{String(i + 1).padStart(2, '0')}</td>
                  <td style={{ fontWeight: 550 }}>{s.title}</td>
                  <td><span className="tag" style={{ background: leverColor[s.lever], color: 'white', borderColor: 'transparent' }}>{t(s.lever)}</span></td>
                  <td className="num" style={{ color: 'var(--pos)', fontWeight: 600 }}>{fmtMoney(s.potential, ccy, { compact: true })}</td>
                  <td>
                    <div className="row" style={{ gap: 8 }}>
                      <div className="prog" style={{ width: 70 }}>
                        <span style={{ width: `${s.confidence}%`, background: s.confidence >= 80 ? 'var(--pos)' : 'var(--warn)' }}></span>
                      </div>
                      <span className="mono num" style={{ fontSize: 11.5 }}>{s.confidence}%</span>
                    </div>
                  </td>
                  <td><span className="tag">{s.effort} · {s.impact}</span></td>
                  <td><button className="btn ghost sm">{Icons.chevron}</button></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}

window.SavingsPage = SavingsPage;
