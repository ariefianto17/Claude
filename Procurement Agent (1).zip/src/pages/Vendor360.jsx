// Vendor 360 page
function Vendor360Page({ lang, ccy, back }) {
  const t = useT(lang);
  const v = DATA.vendor360;
  const [tab, setTab] = React.useState('overview');
  const overallScore = Math.round(v.risks.reduce((s, r) => s + r.score, 0) / v.risks.length);
  return (
    <div className="page">
      <div className="row" style={{ marginBottom: 12 }}>
        <button className="btn ghost sm" onClick={back}>← Back</button>
        <div className="crumbs" style={{ marginLeft: 8 }}>
          <span>Vendors</span>
          <span className="sep">/</span>
          <span className="cur">{v.name}</span>
        </div>
      </div>

      <div className="v360-hero">
        <div className="row" style={{ alignItems: 'flex-start', gap: 20 }}>
          <div className="v-logo">KJ</div>
          <div style={{ flex: 1 }}>
            <div className="v-name">{v.name}</div>
            <div className="v-meta">
              <span className="mono">{v.code}</span>
              <span className="meta-dot">·</span>
              <span>{v.category}</span>
              <span className="meta-dot">·</span>
              <span>Since {v.since}</span>
              <span className="meta-dot">·</span>
              <span>{v.address}</span>
            </div>
            <div className="v-tags">
              <span className="v-tag">⭐ {v.rating} rating</span>
              <span className="v-tag">🟢 Active contract</span>
              <span className="v-tag">FSC certified</span>
              <span className="v-tag">{v.payTerms}</span>
              <span className="v-tag">Tier: {v.tier}</span>
            </div>
          </div>
          <div className="v-score">
            <div className="score-big">{overallScore}</div>
            <div className="score-lbl">Health score</div>
          </div>
        </div>
      </div>

      <div className="tabs">
        {['overview','spend','orders','contracts','documents','activity'].map(x => (
          <button key={x} className={tab === x ? 'on' : ''} onClick={() => setTab(x)}>
            {x[0].toUpperCase() + x.slice(1)}
          </button>
        ))}
      </div>

      {tab === 'overview' && (
        <>
          <div className="grid" style={{ gridTemplateColumns: 'repeat(4, 1fr)', marginBottom: 16 }}>
            <div className="kpi hero">
              <div className="label">YTD spend</div>
              <div className="val">{fmtMoney(v.ytdSpend, ccy, { compact: true })}</div>
              <div className="sub"><span className="delta up">+4.2%</span> vs LY</div>
            </div>
            <div className="kpi">
              <div className="label">OTIF</div>
              <div className="val" style={{ color: 'var(--pos)' }}>{v.otif}%</div>
              <div className="sub"><span className="delta up">+1.8pp</span> 12-mo trend</div>
            </div>
            <div className="kpi">
              <div className="label">Open POs</div>
              <div className="val">{v.openPos}</div>
              <div className="sub">{v.openInvoices} invoices awaiting</div>
            </div>
            <div className="kpi">
              <div className="label">Risk score</div>
              <div className="val" style={{ color: 'var(--pos)' }}>{v.riskScore}/100</div>
              <div className="sub">Low · stable</div>
            </div>
          </div>

          <div className="grid" style={{ gridTemplateColumns: '1.3fr 1fr', marginBottom: 16 }}>
            <div className="card">
              <div className="card-head">
                <div className="card-title">Spend trend · 12 months</div>
                <span className="tag">IDR millions</span>
              </div>
              <div className="card-body">
                <AreaChart data={v.spendByMonth} labels={['Mei','Jun','Jul','Agu','Sep','Okt','Nov','Des','Jan','Feb','Mar','Apr']} color="var(--brand)" format={v => v} />
              </div>
            </div>
            <div className="card">
              <div className="card-head">
                <div className="card-title">Risk breakdown</div>
                <span className="tag brand"><span className="ai-dot"></span>AI monitored</span>
              </div>
              <div className="card-body" style={{ paddingTop: 4 }}>
                {v.risks.map(r => (
                  <div key={r.type} className="risk-row">
                    <div>
                      <div className="r-name">{r.label}</div>
                      <div className="r-note">{r.note}</div>
                    </div>
                    <div className="r-score-pill" style={{
                      background: r.tone === 'pos' ? 'var(--pos-soft)' : r.tone === 'warn' ? 'var(--warn-soft)' : 'var(--neg-soft)',
                      color: r.tone === 'pos' ? 'var(--pos)' : r.tone === 'warn' ? 'var(--warn)' : 'var(--neg)'
                    }}>{r.score}</div>
                    <div className="prog" style={{ height: 6 }}>
                      <span style={{ width: `${r.score}%`, background: r.tone === 'pos' ? 'var(--pos)' : r.tone === 'warn' ? 'var(--warn)' : 'var(--neg)' }}></span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>

          <div className="grid" style={{ gridTemplateColumns: '1fr 1fr' }}>
            <div className="card">
              <div className="card-head">
                <div className="card-title">Recent orders</div>
                <button className="btn ghost sm">{t('view_all')}</button>
              </div>
              <div style={{ padding: 0 }}>
                <table className="tbl">
                  <thead><tr><th>PO</th><th>Date</th><th>Amount</th><th>Status</th></tr></thead>
                  <tbody>
                    {v.pos.map(p => (
                      <tr key={p.id}>
                        <td className="mono" style={{ fontWeight: 600 }}>{p.id}</td>
                        <td style={{ color: 'var(--text-3)' }}>{p.date}</td>
                        <td className="num">{fmtMoney(p.amount, ccy, { compact: true })}</td>
                        <td><span className={'tag ' + (p.status === 'Delivered' ? 'pos' : p.status === 'Closed' ? '' : 'warn')}>{p.status}</span></td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
            <div className="card">
              <div className="card-head">
                <div className="card-title">Activity</div>
              </div>
              <div style={{ padding: 0 }}>
                {v.activity.map((a, i) => (
                  <div key={i} style={{ padding: '12px 18px', borderBottom: i < v.activity.length - 1 ? '1px solid var(--border)' : '0', display: 'flex', gap: 10 }}>
                    <div style={{ width: 24, height: 24, borderRadius: 6, background: 'var(--surface-2)', display: 'grid', placeItems: 'center', fontSize: 10, fontWeight: 700, color: 'var(--text-2)', flexShrink: 0 }}>
                      {a.kind[0].toUpperCase()}
                    </div>
                    <div style={{ flex: 1 }}>
                      <div style={{ fontSize: 13 }}>{a.what}</div>
                      <div style={{ fontSize: 11, color: 'var(--text-4)', marginTop: 2 }}>{a.when}</div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </>
      )}

      {tab !== 'overview' && (
        <div className="card" style={{ padding: 60, textAlign: 'center' }}>
          <div style={{ fontSize: 13, color: 'var(--text-3)' }}>
            <b style={{ color: 'var(--text)' }}>{tab[0].toUpperCase() + tab.slice(1)}</b> — showing this tab's content is out of scope for the first cut.
          </div>
        </div>
      )}
    </div>
  );
}

window.Vendor360Page = Vendor360Page;
