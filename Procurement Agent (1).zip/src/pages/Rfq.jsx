// RFQ Comparison page
function RfqPage({ lang, ccy }) {
  const t = useT(lang);
  const r = DATA.rfq;
  const [selected, setSelected] = React.useState(r.bidders.findIndex(b => b.aiPick));

  const minPrice = Math.min(...r.bidders.map(b => b.price));
  const minLead = Math.min(...r.bidders.map(b => b.lead));
  const maxQual = Math.max(...r.bidders.map(b => b.quality));

  return (
    <div className="page">
      <div className="page-head">
        <div>
          <div className="row" style={{ gap: 8, marginBottom: 4 }}>
            <span className="tag brand mono">{r.id}</span>
            <span className="tag">Open · closes {r.closes}</span>
            <span className="tag">{r.lineItems} line items</span>
          </div>
          <div className="page-title">{t('rfq_title')}</div>
          <div className="page-sub">{r.title} · {r.requester} · Budget {fmtMoney(r.budget, ccy, { compact: true })}</div>
        </div>
        <div className="row">
          <button className="btn">{t('request_final')}</button>
          <button className="btn primary">{Icons.check}{t('award')}</button>
        </div>
      </div>

      {/* AI banner */}
      <div className="ai-hint" style={{ marginBottom: 16, alignItems: 'flex-start', padding: '16px 18px' }}>
        <div className="ai-ic" style={{ width: 28, height: 28, fontSize: 12 }}>AI</div>
        <div style={{ flex: 1 }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 4 }}>
            <strong style={{ fontSize: 14, color: 'var(--text)' }}>{t('ai_recommend_title')}</strong>
            <span className="tag brand">{t('confidence')} 92%</span>
          </div>
          <div style={{ color: 'var(--text-2)', fontSize: 13.5, lineHeight: 1.55 }}>
            <span dangerouslySetInnerHTML={{ __html: t('ai_recommend_body') }} /> <b style={{ color: 'var(--pos)' }}>{fmtMoney(138_000_000, ccy, { compact: true })}</b> {t('vs_baseline')}.
          </div>
          <div className="row" style={{ marginTop: 10, gap: 10, flexWrap: 'wrap' }}>
            <span className="tag pos">Price -7.5% vs LY</span>
            <span className="tag">Lead time 14 d</span>
            <span className="tag">OTIF 96%</span>
            <span className="tag">FSC certified</span>
            <span className="tag">NET 45 payment</span>
          </div>
        </div>
        <div style={{ display: 'flex', gap: 6 }}>
          <button className="btn sm">{t('dismiss')}</button>
          <button className="btn sm primary">{t('apply')}</button>
        </div>
      </div>

      {/* Cards row */}
      <div className="grid" style={{ gridTemplateColumns: 'repeat(4, 1fr)', gap: 16, marginBottom: 18, paddingTop: 10 }}>
        {r.bidders.map((b, i) => (
          <div key={b.name}
               className={'radio-card ' + (selected === i ? 'selected ' : '') + (b.aiPick ? 'ai-pick' : '')}
               onClick={() => setSelected(i)}>
            <div className="row" style={{ justifyContent: 'space-between', marginBottom: 8 }}>
              <div style={{ width: 30, height: 30, borderRadius: 6, background: 'var(--surface-2)', border: '1px solid var(--border)', display: 'grid', placeItems: 'center', fontWeight: 700, fontSize: 11, color: 'var(--text-2)' }}>
                {b.name.replace(/^(PT|CV)\s+/, '').split(' ').map(s => s[0]).slice(0, 2).join('')}
              </div>
              <div className="mono" style={{ fontSize: 10.5, color: 'var(--text-3)', fontWeight: 700 }}>
                SCORE {b.aiScore}
              </div>
            </div>
            <div style={{ fontWeight: 650, fontSize: 14, marginBottom: 4 }}>{b.name}</div>
            <div style={{ fontSize: 11, color: 'var(--text-3)', marginBottom: 12 }}>{b.notes}</div>
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10, fontSize: 12 }}>
              <div>
                <div style={{ color: 'var(--text-3)', fontSize: 10.5, textTransform: 'uppercase', letterSpacing: '0.05em', fontWeight: 600 }}>Price</div>
                <div className="mono" style={{ fontWeight: 600, fontSize: 13, color: b.price === minPrice ? 'var(--pos)' : 'var(--text)' }}>
                  {fmtMoney(b.price, ccy, { compact: true })}
                </div>
              </div>
              <div>
                <div style={{ color: 'var(--text-3)', fontSize: 10.5, textTransform: 'uppercase', letterSpacing: '0.05em', fontWeight: 600 }}>Lead time</div>
                <div className="mono" style={{ fontWeight: 600, fontSize: 13, color: b.lead === minLead ? 'var(--pos)' : 'var(--text)' }}>
                  {b.lead} days
                </div>
              </div>
              <div>
                <div style={{ color: 'var(--text-3)', fontSize: 10.5, textTransform: 'uppercase', letterSpacing: '0.05em', fontWeight: 600 }}>Quality</div>
                <div style={{ fontWeight: 600 }}>
                  <span className="mono">{b.quality}</span>{' '}
                  <span className="stars">{'★'.repeat(Math.round(b.quality))}</span>
                </div>
              </div>
              <div>
                <div style={{ color: 'var(--text-3)', fontSize: 10.5, textTransform: 'uppercase', letterSpacing: '0.05em', fontWeight: 600 }}>OTIF</div>
                <div className="mono" style={{ fontWeight: 600, fontSize: 13 }}>{b.otif}%</div>
              </div>
            </div>
            <div className="divider"></div>
            <div className="row" style={{ gap: 6, flexWrap: 'wrap' }}>
              <span className="tag" style={{ fontSize: 10.5 }}>{b.paymentTerms}</span>
              <span className={'tag ' + (b.risk === 'Low' ? 'pos' : b.risk === 'Medium' ? 'warn' : 'neg')} style={{ fontSize: 10.5 }}>
                {b.risk} risk
              </span>
              {b.tagLowest && <span className="tag" style={{ fontSize: 10.5 }}>Lowest price</span>}
              {b.tagFastest && <span className="tag" style={{ fontSize: 10.5 }}>Fastest</span>}
              {b.tagQuality && <span className="tag" style={{ fontSize: 10.5 }}>Top quality</span>}
            </div>
          </div>
        ))}
      </div>

      {/* Comparison matrix */}
      <div className="card">
        <div className="card-head">
          <div className="card-title">{t('compare_view')}</div>
          <div className="row">
            <div className="seg">
              <button className="on">Scorecard</button>
              <button>Line items</button>
              <button>Vendor health</button>
            </div>
          </div>
        </div>
        <div className="card-body h-scroll" style={{ padding: 0 }}>
          <table className="tbl">
            <thead>
              <tr>
                <th>Criteria</th>
                <th>Weight</th>
                {r.bidders.map(b => <th key={b.name}>{b.name}</th>)}
                <th>AI note</th>
              </tr>
            </thead>
            <tbody>
              {[
                { name: 'Total quoted price', w: '40%', key: 'price', fmt: v => fmtMoney(v, ccy, { compact: true }), best: 'min', aiNote: 'Indoprint is cheapest but OTIF hurts reliability.' },
                { name: 'Lead time', w: '20%', key: 'lead', fmt: v => `${v} days`, best: 'min', aiNote: 'Grafika Mandiri fastest; capacity capped.' },
                { name: 'Quality score', w: '20%', key: 'quality', fmt: v => v.toFixed(1), best: 'max', aiNote: 'Prima Pack leads; price offsets benefit.' },
                { name: 'OTIF history', w: '10%', key: 'otif', fmt: v => `${v}%`, best: 'max', aiNote: 'Kemasan Jaya 96% = best delivery reliability.' },
                { name: 'Composite score', w: '10%', key: 'aiScore', fmt: v => v, best: 'max', aiNote: 'Weighted using procurement policy model.' },
              ].map(row => {
                const vals = r.bidders.map(b => b[row.key]);
                const best = row.best === 'min' ? Math.min(...vals) : Math.max(...vals);
                return (
                  <tr key={row.key}>
                    <td style={{ fontWeight: 600 }}>{row.name}</td>
                    <td className="num mono" style={{ color: 'var(--text-3)' }}>{row.w}</td>
                    {r.bidders.map((b, i) => (
                      <td key={i} className="num">
                        <span style={{
                          fontWeight: 600,
                          color: b[row.key] === best ? 'var(--pos)' : 'var(--text)'
                        }}>
                          {row.fmt(b[row.key])}
                        </span>
                      </td>
                    ))}
                    <td style={{ fontSize: 12, color: 'var(--text-3)', maxWidth: 240 }}>{row.aiNote}</td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}

window.RfqPage = RfqPage;
