// Dashboard — Control Tower page
function KpiCard({ label, value, delta, deltaType = 'up', sub, trend, trendColor = 'var(--brand)' }) {
  return (
    <div className="kpi">
      <div className="label">{label}</div>
      <div className="val">{value}</div>
      <div className="sub">
        {delta && <span className={'delta ' + deltaType}>{deltaType === 'up' ? '↑' : deltaType === 'down' ? '↓' : '·'} {delta}</span>}
        <span>{sub}</span>
      </div>
      {trend && <Sparkline data={trend} color={trendColor} />}
    </div>
  );
}

function DashboardPage({ lang, ccy }) {
  const t = useT(lang);
  const k = DATA.kpis;

  return (
    <div className="page">
      <div className="page-head">
        <div>
          <div className="page-title">{t('dash_title')}</div>
          <div className="page-sub">{t('dash_sub')}</div>
        </div>
        <div className="row">
          <div className="seg">
            <button>{t('last_month')}</button>
            <button className="on">{t('this_month')}</button>
            <button>{t('quarter')}</button>
            <button>{t('ytd')}</button>
          </div>
          <button className="btn">{Icons.download}{t('export')}</button>
          <button className="btn primary">{Icons.plus}{t('new_rfq')}</button>
        </div>
      </div>

      {/* KPIs */}
      <div className="grid" style={{ gridTemplateColumns: 'repeat(6, 1fr)', marginBottom: 16 }}>
        <KpiCard label={t('kpi_spend')} value={fmtMoney(k.spend_ytd_idr, ccy, { compact: true })}
                 delta={`${Math.abs(k.spend_delta)}%`} deltaType="down" sub="vs LY"
                 trend={DATA.spendTrend} />
        <KpiCard label={t('kpi_savings')} value={fmtMoney(k.savings_realized_idr, ccy, { compact: true })}
                 delta={`${k.savings_delta}%`} deltaType="up" sub="vs plan"
                 trend={DATA.savingsTrend} trendColor="var(--pos)" />
        <KpiCard label={t('kpi_cycle')} value={`${k.cycle_days} d`}
                 delta={`${Math.abs(k.cycle_delta)}%`} deltaType="up" sub="faster"
                 trend={DATA.cycleTrend.slice().reverse()} trendColor="var(--info)" />
        <KpiCard label={t('kpi_ontime')} value={fmtPct(k.ontime_pct)}
                 delta={`${k.ontime_delta}pp`} deltaType="up" sub="OTIF" />
        <KpiCard label={t('kpi_compliance')} value={fmtPct(k.po_compliance_pct)}
                 delta={`${Math.abs(k.po_compliance_delta)}pp`} deltaType="warn" sub="vs target 90%" />
        <KpiCard label={t('kpi_vendors')} value={fmtNum(k.active_vendors)}
                 delta={`${k.vendors_delta}`} deltaType="down" sub="rationalized" />
      </div>

      {/* Pipeline */}
      <div className="card" style={{ marginBottom: 16 }}>
        <div className="card-head">
          <div>
            <div className="card-title">{t('pipeline')}</div>
            <div className="card-sub">{t('pipeline_sub')}</div>
          </div>
          <div className="row">
            <span className="tag">{DATA.company.segment}</span>
          </div>
        </div>
        <div className="card-body">
          <div className="flow">
            {DATA.pipeline.map((p, i) => (
              <div key={p.key} className={'flow-stage ' + (i === 1 ? 'active' : '')}>
                <div>{t(p.key)}</div>
                <div className="ct">{p.count}</div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Main row */}
      <div className="grid" style={{ gridTemplateColumns: '1.6fr 1fr', marginBottom: 16 }}>
        <div className="card">
          <div className="card-head">
            <div>
              <div className="card-title">{t('monthly_trend')}</div>
              <div className="card-sub">Spend & savings · 12 mo</div>
            </div>
            <div className="seg">
              <button className="on">Spend</button>
              <button>Savings</button>
              <button>Both</button>
            </div>
          </div>
          <div className="card-body">
            <BarLineChart
              bars={DATA.spendTrend}
              line={DATA.savingsTrend}
              labels={['Mei','Jun','Jul','Agu','Sep','Okt','Nov','Des','Jan','Feb','Mar','Apr']}
            />
            <div className="row" style={{ marginTop: 12, gap: 18, fontSize: 12, color: 'var(--text-3)' }}>
              <span className="row"><span className="dot-ind" style={{ background: 'var(--brand)' }}></span>Spend (IDR M)</span>
              <span className="row"><span className="dot-ind" style={{ background: 'var(--pos)' }}></span>Realized savings (IDR M)</span>
            </div>
          </div>
        </div>

        <div className="card">
          <div className="card-head">
            <div className="card-title">{t('ai_insights')}</div>
            <span className="tag brand"><span className="ai-dot"></span>3 new</span>
          </div>
          <div className="card-body" style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
            {DATA.aiInsights.map((ins, i) => (
              <div key={i} className="ai-hint" style={{ alignItems: 'flex-start' }}>
                <div className="ai-ic">AI</div>
                <div style={{ flex: 1 }}>
                  <div style={{ display: 'flex', gap: 8, alignItems: 'center', marginBottom: 2 }}>
                    <strong style={{ color: 'var(--text)' }}>{ins.title}</strong>
                    <span className={'tag ' + ins.tagType}>{ins.tag}</span>
                  </div>
                  <div style={{ color: 'var(--text-2)', fontSize: 12.5 }}>{ins.body}</div>
                  <div className="row" style={{ marginTop: 8, gap: 6 }}>
                    <button className="btn sm primary">{t('review')}</button>
                    <button className="btn sm ghost">{t('dismiss')}</button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Bottom row */}
      <div className="grid" style={{ gridTemplateColumns: '1fr 1fr 1.1fr' }}>
        <div className="card">
          <div className="card-head">
            <div className="card-title">{t('top_spend_cat')}</div>
            <a className="btn ghost sm">{t('view_all')}</a>
          </div>
          <div className="card-body">
            {DATA.categories.slice(0, 6).map((c) => {
              const max = DATA.categories[0].idr;
              return (
                <div key={c.name} className="bar-row">
                  <div className="lab">{c.name}</div>
                  <div className="bar"><span style={{ width: `${(c.idr / max) * 100}%`, background: c.color }}></span></div>
                  <div className="val">{fmtMoney(c.idr, ccy, { compact: true })}</div>
                </div>
              );
            })}
          </div>
        </div>

        <div className="card">
          <div className="card-head">
            <div className="card-title">{t('delivery_health')}</div>
            <span className="tag pos">OTIF 94.2%</span>
          </div>
          <div className="card-body">
            <div className="donut-row">
              <Donut items={[
                { value: 94.2, color: 'var(--pos)' },
                { value: 4.1, color: 'var(--warn)' },
                { value: 1.7, color: 'var(--neg)' },
              ]} size={150} thickness={20} />
              <div className="legend">
                <div className="legend-item"><span className="sw" style={{background:'var(--pos)'}}></span><span className="nm">On time, in full</span><span className="val">1,842</span><span className="pct">94.2%</span></div>
                <div className="legend-item"><span className="sw" style={{background:'var(--warn)'}}></span><span className="nm">Late but complete</span><span className="val">80</span><span className="pct">4.1%</span></div>
                <div className="legend-item"><span className="sw" style={{background:'var(--neg)'}}></span><span className="nm">Short / damaged</span><span className="val">33</span><span className="pct">1.7%</span></div>
              </div>
            </div>
            <div className="divider"></div>
            <div style={{ fontSize: 12, color: 'var(--text-3)' }}>1,955 deliveries this month across 84 outlets.</div>
          </div>
        </div>

        <div className="card">
          <div className="card-head">
            <div className="card-title">{t('recent_activity')}</div>
            <a className="btn ghost sm">{t('view_all')}</a>
          </div>
          <div className="card-body" style={{ padding: 0 }}>
            {DATA.recentActivity.map((a, i) => (
              <div key={i} style={{
                display: 'flex', gap: 10, padding: '12px 18px',
                borderBottom: i < DATA.recentActivity.length - 1 ? '1px solid var(--border)' : '0',
                alignItems: 'flex-start'
              }}>
                <div style={{
                  width: 26, height: 26, borderRadius: 6,
                  background: a.kind === 'ai' ? 'var(--brand)' : 'var(--surface-2)',
                  color: a.kind === 'ai' ? 'white' : 'var(--text-2)',
                  display: 'grid', placeItems: 'center', fontSize: 11, fontWeight: 700,
                  flexShrink: 0,
                }}>
                  {a.kind === 'ai' ? 'AI' : a.who.split(' ').map(s=>s[0]).slice(0,2).join('')}
                </div>
                <div style={{ flex: 1, minWidth: 0 }}>
                  <div style={{ fontSize: 12.5, color: 'var(--text)', fontWeight: 500 }}>
                    <span style={{ fontWeight: 600 }}>{a.who}</span>
                    <span style={{ color: 'var(--text-3)' }}> · {a.what}</span>
                  </div>
                  <div style={{ fontSize: 11, color: 'var(--text-4)', marginTop: 2 }}>{a.when}</div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

window.DashboardPage = DashboardPage;
