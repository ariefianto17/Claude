// AI Agents page
function AgentsPage({ lang }) {
  const t = useT(lang);
  return (
    <div className="page">
      <div className="page-head">
        <div>
          <div className="page-title">{t('agents_title')}</div>
          <div className="page-sub">{t('agents_sub')}</div>
        </div>
        <div className="row">
          <span className="tag pos">● 6 agents online</span>
          <button className="btn">{Icons.settings}Configure</button>
          <button className="btn primary">{Icons.plus}New agent</button>
        </div>
      </div>

      <div className="ai-hint" style={{ marginBottom: 16, alignItems: 'flex-start' }}>
        <div className="ai-ic">AI</div>
        <div style={{ flex: 1 }}>
          <strong style={{ color: 'var(--text)' }}>This week, your agents saved ~18 hours of manual work</strong>
          <div style={{ color: 'var(--text-2)', fontSize: 12.5, marginTop: 3 }}>
            142 line items categorized · 12 RFQ drafts created · 3 invoice exceptions flagged · 2 negotiation briefs delivered.
          </div>
        </div>
      </div>

      <div className="agents-grid">
        {DATA.agents.map(a => (
          <div key={a.id} className={'agent-card status-' + a.status.toLowerCase()}>
            <div className="agent-glow" style={{ background: a.color }}></div>
            <div className="agent-head">
              <div className="agent-ic" style={{ background: a.color }}>{a.emoji}</div>
              <div style={{ flex: 1 }}>
                <div className="agent-name">{a.name}</div>
                <div style={{ fontSize: 11, color: 'var(--text-3)', display: 'flex', gap: 8, alignItems: 'center', marginTop: 2 }}>
                  <span className="tag" style={{ fontSize: 10, padding: '1px 6px' }}>{a.status}</span>
                  <span>· updated {a.last}</span>
                </div>
              </div>
            </div>
            <div className="agent-desc">{a.desc}</div>
            <div className="agent-task">
              <div style={{ fontSize: 10.5, color: 'var(--text-3)', textTransform: 'uppercase', letterSpacing: '0.05em', fontWeight: 600, marginBottom: 4 }}>Current task</div>
              {a.task}
              {a.progress < 100 && (
                <div className="prog" style={{ marginTop: 8 }}>
                  <span style={{ width: `${a.progress}%`, background: a.color }}></span>
                </div>
              )}
            </div>
            <div className="agent-stats">
              <span>Items: <b>{a.items}</b></span>
              <span>Progress: <b>{a.progress}%</b></span>
            </div>
            <div className="agent-actions">
              <button className="btn sm" style={{ flex: 1 }}>View work</button>
              <button className="btn sm primary" style={{ flex: 1 }}>{Icons.wand}Delegate</button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

window.AgentsPage = AgentsPage;
