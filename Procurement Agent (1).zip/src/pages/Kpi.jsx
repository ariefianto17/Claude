// KPI / Governance page
function KpiPage({ lang, ccy }) {
  const t = useT(lang);
  return (
    <div className="page">
      <div className="page-head">
        <div>
          <div className="page-title">{t('kpi_title')}</div>
          <div className="page-sub">{t('kpi_sub')}</div>
        </div>
        <div className="row">
          <div className="seg">
            <button>{t('last_month')}</button>
            <button className="on">{t('quarter')}</button>
            <button>{t('ytd')}</button>
          </div>
          <button className="btn">{Icons.download}{t('export')}</button>
        </div>
      </div>

      <div className="grid" style={{ gridTemplateColumns: 'repeat(4, 1fr)', marginBottom: 16 }}>
        <KpiCard label={t('policy_comp')} value="93.1%" delta="1.4pp" deltaType="up" sub="target 95%" />
        <KpiCard label={t('avg_cycle')} value="6.4 d" delta="0.9 d" deltaType="up" sub="↓ faster" />
        <KpiCard label={t('sav_vs_target')} value="113.6%" delta="13.6pp" deltaType="up" sub="above target" />
        <KpiCard label={t('exception_rate')} value="0.6%" delta="0.3pp" deltaType="up" sub="target ≤ 1%" />
      </div>

      <div className="grid" style={{ gridTemplateColumns: '1.4fr 1fr', marginBottom: 16 }}>
        <div className="card">
          <div className="card-head">
            <div className="card-title">{t('scorecard')}</div>
            <span className="tag">Q2 FY26</span>
          </div>
          <div style={{ padding: 0 }}>
            <table className="tbl">
              <thead>
                <tr>
                  <th>Metric</th>
                  <th>Target</th>
                  <th>Actual</th>
                  <th>Δ vs LQ</th>
                  <th>{t('status')}</th>
                </tr>
              </thead>
              <tbody>
                {DATA.scorecard.map((s) => (
                  <tr key={s.name}>
                    <td style={{ fontWeight: 550 }}>{s.name}</td>
                    <td className="num" style={{ color: 'var(--text-3)' }}>{s.target}</td>
                    <td className="num" style={{ fontWeight: 650 }}>{s.actual}</td>
                    <td className="num">
                      <span className={'delta ' + (s.status === 'pos' ? 'up' : s.status === 'warn' ? 'warn' : 'down')}>{s.delta}</span>
                    </td>
                    <td>
                      <span className={'tag ' + (s.status === 'pos' ? 'pos' : s.status === 'warn' ? 'warn' : 'neg')}>
                        {s.status === 'pos' ? 'On track' : s.status === 'warn' ? 'At risk' : 'Off track'}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        <div className="card">
          <div className="card-head">
            <div className="card-title">{t('policy_breaches')}</div>
            <span className="tag neg">{DATA.policyBreaches.length} open</span>
          </div>
          <div style={{ padding: 0 }}>
            {DATA.policyBreaches.map((b, i) => (
              <div key={b.id} style={{
                padding: '13px 18px',
                borderBottom: i < DATA.policyBreaches.length - 1 ? '1px solid var(--border)' : '0',
                display: 'flex', gap: 12, alignItems: 'flex-start'
              }}>
                <div style={{ color: b.severity === 'high' ? 'var(--neg)' : b.severity === 'med' ? 'var(--warn)' : 'var(--text-3)', flexShrink: 0 }}>
                  {Icons.alert}
                </div>
                <div style={{ flex: 1, minWidth: 0 }}>
                  <div style={{ fontSize: 13, fontWeight: 550 }}>{b.what}</div>
                  <div style={{ fontSize: 11.5, color: 'var(--text-3)', marginTop: 2 }}>
                    <span className="mono">{b.id}</span> · {b.who} · {b.when}
                  </div>
                </div>
                <span className={'tag ' + (b.severity === 'high' ? 'neg' : b.severity === 'med' ? 'warn' : '')}>
                  {b.severity.toUpperCase()}
                </span>
              </div>
            ))}
          </div>
        </div>
      </div>

      <div className="card">
        <div className="card-head">
          <div className="card-title">Cycle time trend</div>
          <div className="card-sub">PR to PO · 12 months · target ≤ 7 days</div>
        </div>
        <div className="card-body">
          <AreaChart
            data={DATA.cycleTrend}
            labels={['Mei','Jun','Jul','Agu','Sep','Okt','Nov','Des','Jan','Feb','Mar','Apr']}
            color="var(--info)"
            format={v => `${v.toFixed(1)}d`}
            height={220}
          />
        </div>
      </div>
    </div>
  );
}

window.KpiPage = KpiPage;
