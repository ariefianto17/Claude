// AI Categorization page
function CategorizePage({ lang, ccy }) {
  const t = useT(lang);
  const [rows, setRows] = React.useState(DATA.categoryTriage);

  const totalLines = 12_840;
  const auto = 11_247;
  const review = 1_486;
  const manual = totalLines - auto - review;

  const accept = (i) => setRows(rs => rs.filter((_, idx) => idx !== i));

  return (
    <div className="page">
      <div className="page-head">
        <div>
          <div className="page-title">{t('cat_title')}</div>
          <div className="page-sub">{t('cat_sub')}</div>
        </div>
        <div className="row">
          <button className="btn">{Icons.download}{t('export')}</button>
          <button className="btn">{Icons.sparkle}{t('run_reclassify')}</button>
          <button className="btn primary">{Icons.check}{t('accept_all')}</button>
        </div>
      </div>

      <div className="grid" style={{ gridTemplateColumns: 'repeat(4, 1fr)', marginBottom: 16 }}>
        <div className="kpi">
          <div className="label"><span className="ai-dot" style={{ background: 'var(--pos)' }}></span>{t('auto_classified')}</div>
          <div className="val">{fmtNum(auto)}</div>
          <div className="sub"><span className="delta up">87.6%</span> high-confidence ≥ 85%</div>
        </div>
        <div className="kpi">
          <div className="label"><span className="ai-dot" style={{ background: 'var(--warn)' }}></span>{t('needs_review')}</div>
          <div className="val">{fmtNum(review)}</div>
          <div className="sub"><span className="delta warn">11.6%</span> 60–84% confidence</div>
        </div>
        <div className="kpi">
          <div className="label">{t('manual')}</div>
          <div className="val">{fmtNum(manual)}</div>
          <div className="sub"><span className="delta">0.8%</span> below 60% · needs human</div>
        </div>
        <div className="kpi">
          <div className="label">{t('taxonomy')}</div>
          <div className="val">UNSPSC · 4 levels</div>
          <div className="sub"><span className="delta up">+18</span> new sub-categories last month</div>
        </div>
      </div>

      {/* Taxonomy tree + triage queue */}
      <div className="grid" style={{ gridTemplateColumns: '1fr 1.8fr' }}>
        <div className="card">
          <div className="card-head">
            <div className="card-title">{t('taxonomy')}</div>
            <span className="tag brand"><span className="ai-dot"></span>AI</span>
          </div>
          <div className="card-body" style={{ padding: 0 }}>
            {[
              { lvl: 1, name: 'Direct goods', count: 4820, pct: 94 },
              { lvl: 2, name: 'Packaging & Labels', count: 2140, pct: 98 },
              { lvl: 3, name: '  ↳ Kraft bags', count: 890, pct: 99 },
              { lvl: 3, name: '  ↳ Corrugated boxes', count: 720, pct: 97 },
              { lvl: 3, name: '  ↳ Labels & stickers', count: 530, pct: 96 },
              { lvl: 2, name: 'Private Label Goods', count: 1840, pct: 91 },
              { lvl: 1, name: 'Indirect / OPEX', count: 5120, pct: 84 },
              { lvl: 2, name: 'IT & Software', count: 980, pct: 93 },
              { lvl: 2, name: 'Store Maintenance', count: 1240, pct: 72 },
              { lvl: 1, name: 'Services', count: 2900, pct: 88 },
            ].map((n, i) => (
              <div key={i} style={{
                display: 'grid', gridTemplateColumns: '1fr 60px 90px 40px',
                alignItems: 'center', gap: 10,
                padding: '9px 18px',
                borderBottom: '1px solid var(--border)',
                fontSize: 12.5,
                fontWeight: n.lvl === 1 ? 600 : 400,
                color: n.lvl === 1 ? 'var(--text)' : 'var(--text-2)',
                paddingLeft: 18 + (n.lvl - 1) * 12,
                background: n.lvl === 1 ? 'var(--surface-2)' : 'transparent',
              }}>
                <span style={{ whiteSpace: 'pre' }}>{n.name}</span>
                <span className="mono num" style={{ fontSize: 11.5, color: 'var(--text-3)' }}>{fmtNum(n.count)}</span>
                <div className="prog" style={{ height: 5 }}><span style={{ width: `${n.pct}%`, background: n.pct >= 90 ? 'var(--pos)' : n.pct >= 75 ? 'var(--warn)' : 'var(--neg)' }}></span></div>
                <span className="mono num" style={{ fontSize: 11, color: 'var(--text-3)', textAlign: 'right' }}>{n.pct}%</span>
              </div>
            ))}
          </div>
        </div>

        <div className="card">
          <div className="card-head">
            <div>
              <div className="card-title">Review queue</div>
              <div className="card-sub">Low-confidence AI suggestions awaiting human approval</div>
            </div>
            <div className="seg">
              <button className="on">All</button>
              <button>{'< 70%'}</button>
              <button>60-84%</button>
            </div>
          </div>
          <div style={{ padding: 0 }}>
            <table className="tbl">
              <thead>
                <tr>
                  <th>Line item</th>
                  <th>Amount</th>
                  <th>AI suggested category</th>
                  <th>{t('confidence')}</th>
                  <th style={{ width: 180 }}></th>
                </tr>
              </thead>
              <tbody>
                {rows.map((row, i) => (
                  <tr key={i}>
                    <td style={{ maxWidth: 320 }}>
                      <div style={{ fontWeight: 500 }}>{row.desc}</div>
                    </td>
                    <td className="num">{fmtMoney(row.amount, ccy, { compact: true })}</td>
                    <td>
                      <div className="row" style={{ gap: 6 }}>
                        <span style={{ fontSize: 12.5 }}>{row.suggested}</span>
                      </div>
                    </td>
                    <td>
                      <div className="row" style={{ gap: 8 }}>
                        <div className="prog" style={{ width: 70 }}>
                          <span style={{
                            width: `${row.conf}%`,
                            background: row.conf >= 85 ? 'var(--pos)' : row.conf >= 70 ? 'var(--warn)' : 'var(--neg)'
                          }}></span>
                        </div>
                        <span className="mono num" style={{ fontSize: 11.5, minWidth: 30 }}>{row.conf}%</span>
                      </div>
                    </td>
                    <td>
                      <div className="row" style={{ gap: 6, justifyContent: 'flex-end' }}>
                        <button className="btn sm ghost">Edit</button>
                        <button className="btn sm primary" onClick={() => accept(i)}>
                          {Icons.check}Accept
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
                {rows.length === 0 && (
                  <tr><td colSpan="5" style={{ textAlign: 'center', padding: 40, color: 'var(--text-3)' }}>
                    ✨ Review queue cleared. 0 items remaining.
                  </td></tr>
                )}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
}

window.CategorizePage = CategorizePage;
