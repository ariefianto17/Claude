// My Work inbox page
function InboxPage({ lang, ccy, openVendor }) {
  const t = useT(lang);
  const [filter, setFilter] = React.useState('all');
  const typeColors = {
    approval: 'oklch(0.58 0.13 220)',
    award: 'var(--brand)',
    match: 'var(--neg)',
    onboard: 'oklch(0.68 0.12 160)',
    contract: 'oklch(0.70 0.13 30)',
    risk: 'var(--warn)',
    policy: 'var(--neg)',
  };
  const typeLabels = {
    approval: 'APR', award: 'RFQ', match: 'INV', onboard: 'VND', contract: 'CTR', risk: 'RSK', policy: 'POL',
  };
  const filters = [
    { id: 'all', label: 'All', ic: Icons.inbox, tone: 'var(--brand)' },
    { id: 'approval', label: 'Approvals', ic: Icons.check, tone: 'oklch(0.58 0.13 220)' },
    { id: 'match', label: 'Exceptions', ic: Icons.alert, tone: 'var(--neg)' },
    { id: 'risk', label: 'Risks', ic: Icons.shield, tone: 'var(--warn)' },
  ];
  const items = filter === 'all' ? DATA.inbox :
    filter === 'match' ? DATA.inbox.filter(x => x.type === 'match' || x.type === 'policy') :
    DATA.inbox.filter(x => x.type === filter);

  const counts = {
    all: DATA.inbox.length,
    approval: DATA.inbox.filter(x => x.type === 'approval').length,
    match: DATA.inbox.filter(x => x.type === 'match' || x.type === 'policy').length,
    risk: DATA.inbox.filter(x => x.type === 'risk').length,
  };

  return (
    <div className="page">
      <div className="page-head">
        <div>
          <div className="page-title">{t('inbox_title')}</div>
          <div className="page-sub">{t('inbox_sub')}</div>
        </div>
        <div className="row">
          <span className="tag brand"><span className="ai-dot"></span>AI pre-ranked by impact</span>
          <button className="btn">{Icons.filter}{t('filter')}</button>
        </div>
      </div>

      <div className="inbox-head-stats">
        {filters.map(f => (
          <div key={f.id} className={'stat-chip ' + (filter === f.id ? 'active' : '')} onClick={() => setFilter(f.id)}>
            <div className="ic-bubble" style={{ background: f.tone + '22', color: f.tone }}>{f.ic}</div>
            <div>
              <div className="n">{counts[f.id]}</div>
              <div className="sub-n">{f.label}</div>
            </div>
          </div>
        ))}
      </div>

      <div className="card">
        <div className="card-head">
          <div>
            <div className="card-title">Queue · {items.length} items</div>
            <div className="card-sub">Sorted by SLA & impact · oldest due first</div>
          </div>
          <div className="seg">
            <button className="on">Priority</button>
            <button>Due date</button>
            <button>Amount</button>
          </div>
        </div>
        <div style={{ padding: 0 }}>
          {items.map((x, i) => (
            <div key={x.id} className="inbox-row" onClick={() => x.vendor.startsWith('PT Kemasan') && openVendor && openVendor()}>
              <div className="type-badge" style={{ background: typeColors[x.type] }}>{typeLabels[x.type]}</div>
              <div>
                <div className="title">{x.title}</div>
                <div className="sub">
                  <span className="mono">{x.id}</span> · {x.vendor}
                  {x.amount && <> · <span className="mono">{fmtMoney(x.amount, ccy, { compact: true })}</span></>}
                  {' · '} {x.who} · {x.when}
                </div>
                <div className="ai-note">{x.aiNote}</div>
              </div>
              <div>
                <div style={{ fontSize: 11, color: 'var(--text-3)', textTransform: 'uppercase', letterSpacing: '0.05em', fontWeight: 600, marginBottom: 3 }}>SLA</div>
                <span className={'tag ' + x.slaTone}>{x.sla}</span>
              </div>
              <div>
                <span className={'tag ' + (x.priority === 'high' ? 'neg' : x.priority === 'med' ? 'warn' : '')}>
                  {x.priority === 'high' ? '● High' : x.priority === 'med' ? '● Med' : '● Low'}
                </span>
              </div>
              <div className="row" style={{ gap: 6, justifyContent: 'flex-end' }}>
                <button className="btn sm">Open</button>
                <button className="btn sm primary">{Icons.check}Act</button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

window.InboxPage = InboxPage;
