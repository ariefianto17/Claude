// Spend Analysis page
function SpendPage({ lang, ccy }) {
  const t = useT(lang);
  const totalSpend = DATA.categories.reduce((s, c) => s + c.idr, 0);
  const totalBu = DATA.businessUnits.reduce((s, b) => s + b.idr, 0);

  return (
    <div className="page">
      <div className="page-head">
        <div>
          <div className="page-title">{t('spend_title')}</div>
          <div className="page-sub">{t('spend_sub')}</div>
        </div>
        <div className="row">
          <div className="seg">
            <button>{t('all_categories')}</button>
            <button className="on">{t('cat_direct')}</button>
            <button>{t('cat_indirect')}</button>
            <button>{t('cat_services')}</button>
          </div>
          <button className="btn">{Icons.filter}{t('filter')}</button>
          <button className="btn">{Icons.download}{t('export')}</button>
        </div>
      </div>

      {/* KPI strip */}
      <div className="grid" style={{ gridTemplateColumns: 'repeat(4, 1fr)', marginBottom: 16 }}>
        <KpiCard label={t('kpi_spend') + ' (YTD)'} value={fmtMoney(totalSpend, ccy, { compact: true })}
                 delta="3.2%" deltaType="down" sub="vs LY" trend={DATA.spendTrend} />
        <KpiCard label={t('tail_spend')} value={fmtMoney(3_240_000_000, ccy, { compact: true })}
                 delta="7.7%" deltaType="warn" sub="61 vendors < Rp 50jt" />
        <KpiCard label={t('maverick')} value="6.9%"
                 delta="0.4pp" deltaType="warn" sub="of total spend" />
        <KpiCard label="Addressable" value={fmtMoney(28_800_000_000, ccy, { compact: true })}
                 delta="68%" deltaType="up" sub="under mgmt" />
      </div>

      <div className="grid" style={{ gridTemplateColumns: '1.4fr 1fr', marginBottom: 16 }}>
        <div className="card">
          <div className="card-head">
            <div>
              <div className="card-title">{t('by_category')}</div>
              <div className="card-sub">10 categories · {fmtMoney(totalSpend, ccy, { compact: true })} total</div>
            </div>
            <div className="seg">
              <button className="on">YTD</button>
              <button>Quarter</button>
              <button>Month</button>
            </div>
          </div>
          <div className="card-body">
            <div className="donut-row">
              <Donut items={DATA.categories.map(c => ({ value: c.idr, color: c.color }))} size={200} thickness={28} />
              <div className="legend" style={{ flex: 1 }}>
                {DATA.categories.map(c => (
                  <div key={c.name} className="legend-item">
                    <span className="sw" style={{ background: c.color }}></span>
                    <span className="nm">{c.name}</span>
                    <span className="val">{fmtMoney(c.idr, ccy, { compact: true })}</span>
                    <span className="pct">{c.share.toFixed(1)}%</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>

        <div className="card">
          <div className="card-head">
            <div>
              <div className="card-title">{t('by_bu')}</div>
              <div className="card-sub">Business unit allocation</div>
            </div>
          </div>
          <div className="card-body">
            {DATA.businessUnits.map((b, i) => {
              const pct = (b.idr / totalBu) * 100;
              const colors = ['var(--brand)', 'oklch(0.58 0.13 220)', 'oklch(0.62 0.12 195)', 'oklch(0.68 0.10 170)', 'oklch(0.72 0.10 140)', 'oklch(0.76 0.11 90)'];
              return (
                <div key={b.name} style={{ marginBottom: 14 }}>
                  <div className="row" style={{ justifyContent: 'space-between', marginBottom: 6 }}>
                    <span style={{ fontWeight: 500, fontSize: 13 }}>{b.name}</span>
                    <span className="mono num" style={{ fontSize: 12 }}>{fmtMoney(b.idr, ccy, { compact: true })} · {pct.toFixed(1)}%</span>
                  </div>
                  <div className="prog"><span style={{ width: `${pct}%`, background: colors[i] }}></span></div>
                </div>
              );
            })}
          </div>
        </div>
      </div>

      {/* Vendor OTIF heatmap */}
      <div className="card" style={{ marginBottom: 16 }}>
        <div className="card-head">
          <div>
            <div className="card-title">Vendor OTIF heatmap</div>
            <div className="card-sub">Rolling 12 months · on-time-in-full % by vendor</div>
          </div>
          <div className="row" style={{ gap: 12, fontSize: 11, color: 'var(--text-3)' }}>
            <span className="row"><span className="dot-ind" style={{ background: heatColor(75) }}></span>75%</span>
            <span className="row"><span className="dot-ind" style={{ background: heatColor(85) }}></span>85%</span>
            <span className="row"><span className="dot-ind" style={{ background: heatColor(95) }}></span>95%+</span>
          </div>
        </div>
        <div className="card-body">
          <div className="hm-grid">
            <div></div>
            {DATA.heatmap.months.map(m => <div key={m} className="hm-top">{m}</div>)}
            {DATA.heatmap.rows.map((r, ri) => (
              <React.Fragment key={r}>
                <div className="hm-lab">{r}</div>
                {DATA.heatmap.values[ri].map((v, ci) => (
                  <div key={ci} className="hm-cell" style={{ background: heatColor(v) }} title={`${r} · ${DATA.heatmap.months[ci]}: ${v}%`}>{v}</div>
                ))}
              </React.Fragment>
            ))}
          </div>
        </div>
      </div>

      {/* Top vendors */}
      <div className="card">
        <div className="card-head">
          <div className="card-title">{t('top_vendors')}</div>
          <div className="row">
            <span className="tag">By spend</span>
            <button className="btn ghost sm">{t('view_all')}</button>
          </div>
        </div>
        <div style={{ padding: 0 }}>
          <table className="tbl">
            <thead>
              <tr>
                <th style={{ width: 32 }}>#</th>
                <th>Vendor</th>
                <th>Category</th>
                <th>YTD spend</th>
                <th>Share</th>
                <th>OTIF</th>
                <th>Risk</th>
                <th></th>
              </tr>
            </thead>
            <tbody>
              {DATA.topVendors.map((v, i) => {
                const share = (v.idr / totalSpend) * 100;
                return (
                  <tr key={v.name}>
                    <td className="mono num" style={{ color: 'var(--text-3)' }}>{String(i + 1).padStart(2, '0')}</td>
                    <td>
                      <div className="row" style={{ gap: 10 }}>
                        <div style={{ width: 28, height: 28, borderRadius: 6, background: 'var(--surface-2)', border: '1px solid var(--border)', display: 'grid', placeItems: 'center', fontSize: 10.5, fontWeight: 700, color: 'var(--text-2)' }}>
                          {v.name.replace(/^(PT|CV)\s+/, '').split(' ').map(s => s[0]).slice(0, 2).join('')}
                        </div>
                        <span style={{ fontWeight: 600 }}>{v.name}</span>
                      </div>
                    </td>
                    <td><span className="tag">{v.cat}</span></td>
                    <td className="num">{fmtMoney(v.idr, ccy, { compact: true })}</td>
                    <td>
                      <div className="row" style={{ gap: 8 }}>
                        <div className="prog" style={{ width: 90 }}><span style={{ width: `${share * 5}%` }}></span></div>
                        <span className="mono num" style={{ fontSize: 11.5 }}>{share.toFixed(1)}%</span>
                      </div>
                    </td>
                    <td className="num">
                      <span style={{ color: v.otif >= 92 ? 'var(--pos)' : v.otif >= 85 ? 'var(--warn)' : 'var(--neg)', fontWeight: 600 }}>
                        {v.otif}%
                      </span>
                    </td>
                    <td><span className={'tag ' + (v.risk === 'low' ? 'pos' : v.risk === 'med' ? 'warn' : 'neg')}>{v.risk.toUpperCase()}</span></td>
                    <td><button className="btn ghost sm">{Icons.more}</button></td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}

window.SpendPage = SpendPage;
