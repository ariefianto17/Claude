// Small chart primitives — pure SVG, no external libraries

function Sparkline({ data, color = 'var(--brand)', height = 34, fill = true, strokeW = 1.75 }) {
  const w = 120;
  const h = height;
  const min = Math.min(...data);
  const max = Math.max(...data);
  const range = max - min || 1;
  const step = w / (data.length - 1);
  const pts = data.map((v, i) => [i * step, h - ((v - min) / range) * (h - 6) - 3]);
  const d = pts.map((p, i) => `${i ? 'L' : 'M'}${p[0].toFixed(1)} ${p[1].toFixed(1)}`).join(' ');
  const area = `${d} L${w} ${h} L0 ${h} Z`;
  return (
    <svg viewBox={`0 0 ${w} ${h}`} className="spark" preserveAspectRatio="none">
      {fill && (
        <>
          <defs>
            <linearGradient id={'g-' + (color.replace(/[^a-z]/gi, '') + data.length)} x1="0" x2="0" y1="0" y2="1">
              <stop offset="0" stopColor={color} stopOpacity="0.28" />
              <stop offset="1" stopColor={color} stopOpacity="0" />
            </linearGradient>
          </defs>
          <path d={area} fill={`url(#g-${color.replace(/[^a-z]/gi, '') + data.length})`} />
        </>
      )}
      <path d={d} fill="none" stroke={color} strokeWidth={strokeW} strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  );
}

// Area + line chart with axis
function AreaChart({ data, labels, height = 220, color = 'var(--brand)', format = (v) => v, tickCount = 4 }) {
  const w = 680;
  const h = height;
  const padL = 48, padR = 12, padT = 10, padB = 24;
  const iw = w - padL - padR;
  const ih = h - padT - padB;
  const min = 0;
  const max = Math.max(...data) * 1.12;
  const step = iw / (data.length - 1);
  const y = v => padT + ih - ((v - min) / (max - min)) * ih;
  const x = i => padL + i * step;
  const pts = data.map((v, i) => [x(i), y(v)]);
  const d = pts.map((p, i) => `${i ? 'L' : 'M'}${p[0]} ${p[1]}`).join(' ');
  const area = `${d} L${x(data.length - 1)} ${padT + ih} L${padL} ${padT + ih} Z`;
  const ticks = Array.from({ length: tickCount + 1 }, (_, i) => min + (i / tickCount) * (max - min));
  return (
    <svg viewBox={`0 0 ${w} ${h}`} width="100%" style={{ display: 'block' }}>
      <defs>
        <linearGradient id="area-g" x1="0" x2="0" y1="0" y2="1">
          <stop offset="0" stopColor={color} stopOpacity="0.22" />
          <stop offset="1" stopColor={color} stopOpacity="0" />
        </linearGradient>
      </defs>
      {ticks.map((t, i) => (
        <g key={i}>
          <line x1={padL} x2={w - padR} y1={y(t)} y2={y(t)} stroke="var(--border)" strokeDasharray={i === 0 ? '' : '2 3'} />
          <text x={padL - 8} y={y(t) + 3} fontSize="10" fill="var(--text-3)" textAnchor="end" fontFamily="var(--font-mono)">{format(t)}</text>
        </g>
      ))}
      <path d={area} fill="url(#area-g)" />
      <path d={d} fill="none" stroke={color} strokeWidth="2" strokeLinejoin="round" strokeLinecap="round" />
      {pts.map((p, i) => (
        <circle key={i} cx={p[0]} cy={p[1]} r="2.5" fill="var(--surface)" stroke={color} strokeWidth="1.5" />
      ))}
      {labels && labels.map((l, i) => (
        <text key={i} x={x(i)} y={h - 6} fontSize="10.5" fill="var(--text-3)" textAnchor="middle" fontFamily="var(--font-mono)">{l}</text>
      ))}
    </svg>
  );
}

// Bar + line combo
function BarLineChart({ bars, line, labels, height = 220, barColor = 'var(--brand)', lineColor = 'var(--pos)' }) {
  const w = 680;
  const h = height;
  const padL = 48, padR = 48, padT = 14, padB = 26;
  const iw = w - padL - padR;
  const ih = h - padT - padB;
  const bMax = Math.max(...bars) * 1.15;
  const lMax = Math.max(...line) * 1.15;
  const bw = iw / bars.length;
  const lineY = v => padT + ih - (v / lMax) * ih;
  const barY = v => padT + ih - (v / bMax) * ih;
  const pts = line.map((v, i) => [padL + bw * (i + 0.5), lineY(v)]);
  const d = pts.map((p, i) => `${i ? 'L' : 'M'}${p[0]} ${p[1]}`).join(' ');
  return (
    <svg viewBox={`0 0 ${w} ${h}`} width="100%" style={{ display: 'block' }}>
      {[0, 0.25, 0.5, 0.75, 1].map((t, i) => (
        <line key={i} x1={padL} x2={w - padR} y1={padT + ih * (1 - t)} y2={padT + ih * (1 - t)} stroke="var(--border)" strokeDasharray={i === 0 ? '' : '2 3'} />
      ))}
      {bars.map((v, i) => (
        <rect key={i}
          x={padL + bw * i + 4}
          width={bw - 8}
          y={barY(v)}
          height={padT + ih - barY(v)}
          rx="3"
          fill={barColor}
          opacity="0.85" />
      ))}
      <path d={d} fill="none" stroke={lineColor} strokeWidth="2.25" strokeLinejoin="round" strokeLinecap="round" />
      {pts.map((p, i) => (
        <circle key={i} cx={p[0]} cy={p[1]} r="3" fill="var(--surface)" stroke={lineColor} strokeWidth="1.75" />
      ))}
      {labels.map((l, i) => (
        <text key={i} x={padL + bw * (i + 0.5)} y={h - 8} fontSize="10.5" fill="var(--text-3)" textAnchor="middle" fontFamily="var(--font-mono)">{l}</text>
      ))}
    </svg>
  );
}

function Donut({ items, size = 160, thickness = 22 }) {
  const total = items.reduce((s, i) => s + i.value, 0);
  const r = size / 2 - thickness / 2;
  const C = 2 * Math.PI * r;
  let acc = 0;
  return (
    <svg viewBox={`0 0 ${size} ${size}`} width={size} height={size}>
      <circle cx={size / 2} cy={size / 2} r={r} fill="none" stroke="var(--surface-2)" strokeWidth={thickness} />
      {items.map((it, i) => {
        const len = (it.value / total) * C;
        const gap = 2;
        const el = (
          <circle key={i}
            cx={size / 2} cy={size / 2} r={r}
            fill="none"
            stroke={it.color}
            strokeWidth={thickness}
            strokeDasharray={`${Math.max(0, len - gap)} ${C}`}
            strokeDashoffset={-acc}
            transform={`rotate(-90 ${size / 2} ${size / 2})`}
            strokeLinecap="butt"
          />
        );
        acc += len;
        return el;
      })}
    </svg>
  );
}

// Heatmap cell color based on value
function heatColor(v, min = 70, max = 100) {
  const t = Math.max(0, Math.min(1, (v - min) / (max - min)));
  // Bad (red) -> Good (green) via neutral — use oklch
  const L = 0.72;
  const C = 0.14;
  const H = 30 + t * 120; // 30 (red) → 150 (green)
  return `oklch(${L} ${C} ${H})`;
}

window.Sparkline = Sparkline;
window.AreaChart = AreaChart;
window.BarLineChart = BarLineChart;
window.Donut = Donut;
window.heatColor = heatColor;
