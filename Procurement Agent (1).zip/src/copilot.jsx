// Copilot drawer + Tweaks panel
function Copilot({ open, onClose, lang }) {
  const t = useT(lang);
  const [msgs, setMsgs] = React.useState([
    { who: 'ai', body: 'Selamat pagi, Maya 👋 I\'ve pre-scanned today\'s spend. Here\'s what I\'d prioritize:' },
    { who: 'ai', body: '1. Award RFQ-0184 to Kemasan Jaya (saves Rp 138 jt vs LY)\n2. Review 3 duplicate invoices from PT Indoprint — flagged at 09:12\n3. Renegotiate Logistik Nusantara rate card — market -9.4%', tools: ['Open RFQ-0184', 'Show duplicates', 'Draft renegotiation email'] },
  ]);
  const [q, setQ] = React.useState('');

  const send = () => {
    if (!q.trim()) return;
    const userQ = q.trim();
    setMsgs(m => [...m, { who: 'user', body: userQ }]);
    setQ('');
    setTimeout(() => {
      setMsgs(m => [...m, {
        who: 'ai',
        body: 'Here\'s what I found: Packaging spend is up 4.1% QoQ, driven by kraft bag volume at outlets BSD and Kelapa Gading. 82% is concentrated in 2 vendors. Consolidating could save ~Rp 640 jt.',
        tools: ['See breakdown', 'Start consolidation RFQ'],
      }]);
    }, 600);
  };

  return (
    <div className={'copilot ' + (open ? 'open' : '')}>
      <div className="copilot-head">
        <div style={{ width: 30, height: 30, borderRadius: 8, background: 'linear-gradient(135deg, var(--brand), var(--brand-2))', display: 'grid', placeItems: 'center', color: 'white', fontWeight: 700, fontSize: 12 }}>AI</div>
        <div style={{ flex: 1 }}>
          <div style={{ fontWeight: 650, fontSize: 14 }}>{t('copilot')}</div>
          <div style={{ fontSize: 11, color: 'var(--text-3)' }}>Trained on PT Sinar Niaga data · v2.4</div>
        </div>
        <button className="icon-btn" onClick={onClose}>{Icons.close}</button>
      </div>
      <div className="copilot-body">
        {msgs.map((m, i) => (
          <div key={i} className={'msg ' + m.who}>
            <div className="bubble" style={{ whiteSpace: 'pre-wrap' }}>{m.body}</div>
            {m.tools && (
              <div className="tools">
                {m.tools.map(x => <button key={x} className="btn sm">{x}</button>)}
              </div>
            )}
          </div>
        ))}
        <div style={{ fontSize: 11, color: 'var(--text-4)', marginTop: 4, textAlign: 'center' }}>
          ✨ Suggested prompts
        </div>
        <div style={{ display: 'flex', flexWrap: 'wrap', gap: 6, justifyContent: 'center', marginTop: 8 }}>
          {['Top 5 overspend categories', 'Vendor health summary', 'Draft RFQ for packaging', 'Explain maverick spend'].map(p => (
            <button key={p} className="btn sm" onClick={() => { setQ(p); }}>{p}</button>
          ))}
        </div>
      </div>
      <div className="copilot-input">
        <input
          placeholder="Ask about spend, vendors, KPIs…"
          value={q}
          onChange={e => setQ(e.target.value)}
          onKeyDown={e => e.key === 'Enter' && send()}
        />
        <button className="btn primary" onClick={send}>{Icons.send}</button>
      </div>
    </div>
  );
}

function TweaksPanel({ theme, setTheme, density, setDensity, copilotDock, setCopilotDock, onClose }) {
  return (
    <div className="tweaks-panel">
      <div className="row" style={{ justifyContent: 'space-between' }}>
        <h4 style={{ margin: 0 }}>Tweaks</h4>
        <button className="icon-btn" style={{ width: 24, height: 24 }} onClick={onClose}>{Icons.close}</button>
      </div>
      <div className="tweaks-row">
        <span>Theme</span>
        <div className="chip-toggle">
          <button className={theme === 'light' ? 'on' : ''} onClick={() => setTheme('light')}>Light</button>
          <button className={theme === 'dark' ? 'on' : ''} onClick={() => setTheme('dark')}>Dark</button>
        </div>
      </div>
      <div className="tweaks-row">
        <span>Density</span>
        <div className="chip-toggle">
          <button className={density === 'comfy' ? 'on' : ''} onClick={() => setDensity('comfy')}>Comfy</button>
          <button className={density === 'compact' ? 'on' : ''} onClick={() => setDensity('compact')}>Compact</button>
        </div>
      </div>
      <div className="tweaks-row">
        <span>AI Copilot</span>
        <div className="chip-toggle">
          <button className={copilotDock === 'fab' ? 'on' : ''} onClick={() => setCopilotDock('fab')}>Floating</button>
          <button className={copilotDock === 'off' ? 'on' : ''} onClick={() => setCopilotDock('off')}>Hidden</button>
        </div>
      </div>
    </div>
  );
}

window.Copilot = Copilot;
window.TweaksPanel = TweaksPanel;
