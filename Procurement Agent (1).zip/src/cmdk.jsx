// Command Bar (⌘K)
function CommandBar({ open, onClose, setPage, openWizard, openVendor }) {
  const [q, setQ] = React.useState('');
  const [active, setActive] = React.useState(0);
  const inputRef = React.useRef(null);

  const cmds = [
    { section: 'Actions', items: [
      { label: 'Create new RFQ', sub: 'Start guided 5-step wizard', ic: Icons.plus, action: () => { openWizard(); onClose(); } },
      { label: 'Create purchase request', sub: 'Submit a new PR', ic: Icons.plus, action: () => onClose() },
      { label: 'Onboard new vendor', sub: 'Add vendor + AI doc intake', ic: Icons.vendors, action: () => onClose() },
      { label: 'Ask AIBuy Copilot', sub: 'Natural language over your data', ic: Icons.sparkle, action: () => onClose() },
    ]},
    { section: 'Navigate', items: [
      { label: 'My Work inbox', sub: '8 items waiting', ic: Icons.inbox, action: () => { setPage('inbox'); onClose(); } },
      { label: 'Control Tower', sub: 'Dashboard', ic: Icons.dashboard, action: () => { setPage('dashboard'); onClose(); } },
      { label: 'AI Agents', sub: '6 agents online', ic: Icons.agent, action: () => { setPage('agents'); onClose(); } },
      { label: 'Savings Opportunities', sub: 'Rp 1.99 M potential', ic: Icons.savings, action: () => { setPage('savings'); onClose(); } },
      { label: 'Spend Analysis', sub: 'Deep-dive', ic: Icons.spend, action: () => { setPage('spend'); onClose(); } },
    ]},
    { section: 'Jump to', items: [
      { label: 'PT Kemasan Jaya Abadi', sub: 'Vendor · Strategic', ic: Icons.building, action: () => { openVendor(); onClose(); } },
      { label: 'RFQ-2026-0184', sub: 'Open · Packaging refill', ic: Icons.sourcing, action: () => { setPage('rfq'); onClose(); } },
    ]},
  ];

  const flat = [];
  cmds.forEach(s => s.items.forEach(it => flat.push({ ...it, section: s.section })));
  const filtered = q.trim()
    ? flat.filter(x => (x.label + ' ' + x.sub + ' ' + x.section).toLowerCase().includes(q.toLowerCase()))
    : flat;

  React.useEffect(() => {
    if (open && inputRef.current) inputRef.current.focus();
    setActive(0); setQ('');
  }, [open]);

  const onKey = (e) => {
    if (e.key === 'ArrowDown') { e.preventDefault(); setActive(a => Math.min(filtered.length - 1, a + 1)); }
    if (e.key === 'ArrowUp') { e.preventDefault(); setActive(a => Math.max(0, a - 1)); }
    if (e.key === 'Enter') { filtered[active] && filtered[active].action(); }
    if (e.key === 'Escape') onClose();
  };

  if (!open) return null;
  const grouped = {};
  filtered.forEach(x => { (grouped[x.section] ||= []).push(x); });

  return (
    <div className="cmdk-overlay" onClick={onClose}>
      <div className="cmdk" onClick={e => e.stopPropagation()}>
        <div className="cmdk-input">
          {Icons.search}
          <input ref={inputRef} placeholder="Search actions, pages, vendors, POs…" value={q}
                 onChange={e => { setQ(e.target.value); setActive(0); }} onKeyDown={onKey} />
          <kbd>ESC</kbd>
        </div>
        <div className="cmdk-list">
          {Object.entries(grouped).map(([sec, items]) => (
            <div key={sec}>
              <div className="cmdk-section">{sec}</div>
              {items.map((it, i) => {
                const idx = filtered.indexOf(it);
                return (
                  <div key={i} className={'cmdk-item ' + (idx === active ? 'active' : '')}
                       onMouseEnter={() => setActive(idx)}
                       onClick={() => it.action()}>
                    <div className="cmd-ic">{it.ic}</div>
                    <div className="cmd-body">
                      <div style={{ fontWeight: 550 }}>{it.label}</div>
                      <div className="cmd-sub">{it.sub}</div>
                    </div>
                    <span className="cmd-kbd">↵</span>
                  </div>
                );
              })}
            </div>
          ))}
          {filtered.length === 0 && <div style={{ padding: 30, textAlign: 'center', color: 'var(--text-3)', fontSize: 13 }}>No results for "{q}"</div>}
        </div>
      </div>
    </div>
  );
}

window.CommandBar = CommandBar;
