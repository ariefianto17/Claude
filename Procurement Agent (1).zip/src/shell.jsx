// App shell — sidebar, topbar, and page routing
const { useState, useEffect, useMemo, useRef } = React;

function useT(lang) {
  return (k) => (window.I18N[lang] && window.I18N[lang][k]) || k;
}

function Sidebar({ lang, page, setPage }) {
  const t = useT(lang);
  const groups = [
    {
      label: t('nav_work') || 'Work',
      items: [
        { id: 'inbox', icon: Icons.inbox, label: t('nav_inbox'), badge: '8' },
        { id: 'agents', icon: Icons.agent, label: t('nav_agents'), badge: 'AI' },
      ],
    },
    {
      label: t('nav_operate'),
      items: [
        { id: 'dashboard', icon: Icons.dashboard, label: t('nav_dashboard') },
        { id: 'rfq', icon: Icons.sourcing, label: t('nav_sourcing'), badge: '12' },
        { id: 'orders', icon: Icons.orders, label: t('nav_orders') },
        { id: 'vendors', icon: Icons.vendors, label: t('nav_vendors') },
        { id: 'contracts', icon: Icons.contracts, label: t('nav_contracts') },
      ],
    },
    {
      label: t('nav_optimize'),
      items: [
        { id: 'spend', icon: Icons.spend, label: t('nav_spend') },
        { id: 'categorize', icon: Icons.categorize, label: t('nav_categorize'), badge: 'AI' },
        { id: 'savings', icon: Icons.savings, label: t('nav_savings'), badge: '6' },
      ],
    },
    {
      label: t('nav_govern'),
      items: [
        { id: 'kpi', icon: Icons.kpi, label: t('nav_kpi') },
        { id: 'settings', icon: Icons.settings, label: t('nav_settings') },
      ],
    },
  ];
  return (
    <aside className="sidebar">
      <div className="sb-brand">
        <div className="sb-logo">A</div>
        <div>
          <div className="sb-name">AIBuy</div>
          <div className="sb-tag">Procurement Intelligence</div>
        </div>
      </div>
      <nav className="sb-nav">
        {groups.map(g => (
          <div key={g.label}>
            <div className="sb-group">{g.label}</div>
            {g.items.map(it => (
              <div
                key={it.id}
                className={'sb-item ' + (page === it.id ? 'active' : '')}
                onClick={() => setPage(it.id)}>
                {it.icon}
                <span>{it.label}</span>
                {it.badge && <span className="badge">{it.badge}</span>}
              </div>
            ))}
          </div>
        ))}
      </nav>
      <div className="sb-foot">
        <div className="avatar">MH</div>
        <div style={{ flex: 1, minWidth: 0 }}>
          <div className="u-name">Maya Handoko</div>
          <div className="u-role">Head of Procurement</div>
        </div>
        {Icons.chevron}
      </div>
    </aside>
  );
}

function Topbar({ lang, setLang, ccy, setCcy, theme, setTheme, openCopilot, openCmdk, openWizard, pageLabel, plain, setPlain }) {
  const t = useT(lang);
  return (
    <div className="topbar">
      <div className="crumbs">
        <span>{DATA.company.name}</span>
        <span className="sep">/</span>
        <span className="cur">{pageLabel}</span>
      </div>
      <div className="search" onClick={openCmdk} style={{ cursor: 'pointer' }}>
        {Icons.search}
        <input placeholder={t('search_ph')} readOnly style={{ cursor: 'pointer' }} />
        <kbd>⌘K</kbd>
      </div>
      <div className="top-actions">
        <button className="btn" onClick={openWizard} title="Create new RFQ">
          {Icons.plus}
          {t('new_pr')}
        </button>
        <button className={'icon-btn ' + (plain ? 'on' : '')} title={t('plain_mode')} onClick={() => setPlain(!plain)}
                style={plain ? { background: 'var(--brand-soft)', color: 'var(--brand-ink)' } : {}}>
          {Icons.help}
        </button>
        <div className="chip-toggle" title="Language">
          <button className={lang === 'id' ? 'on' : ''} onClick={() => setLang('id')}>ID</button>
          <button className={lang === 'en' ? 'on' : ''} onClick={() => setLang('en')}>EN</button>
        </div>
        <div className="chip-toggle" title="Currency">
          <button className={ccy === 'IDR' ? 'on' : ''} onClick={() => setCcy('IDR')}>IDR</button>
          <button className={ccy === 'USD' ? 'on' : ''} onClick={() => setCcy('USD')}>USD</button>
        </div>
        <button className="icon-btn" title="Theme" onClick={() => setTheme(theme === 'dark' ? 'light' : 'dark')}>
          {theme === 'dark' ? Icons.sun : Icons.moon}
        </button>
        <button className="icon-btn" title="Notifications">
          {Icons.bell}
          <span className="dot"></span>
        </button>
        <button className="btn primary" onClick={openCopilot}>
          {Icons.sparkle}
          {t('ask_ai')}
        </button>
      </div>
    </div>
  );
}

window.Sidebar = Sidebar;
window.Topbar = Topbar;
window.useT = useT;
