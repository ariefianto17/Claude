// Seed data for the AIBuy demo — Indonesian retail/distribution flavor
const DATA = {
  company: {
    name: 'PT Sinar Niaga Retail',
    segment: 'Retail distribution — 84 outlets across Jabodetabek, Bandung, Surabaya',
  },

  // Dashboard KPIs
  kpis: {
    spend_ytd_idr: 42_350_000_000,
    spend_delta: -3.2, // % vs LY
    savings_realized_idr: 2_840_000_000,
    savings_delta: 18.6,
    cycle_days: 6.4,
    cycle_delta: -12.5,
    ontime_pct: 94.2,
    ontime_delta: 1.8,
    po_compliance_pct: 87.5,
    po_compliance_delta: -2.1,
    active_vendors: 318,
    vendors_delta: -14,
  },

  // Pipeline
  pipeline: [
    { key: 'pr_draft', count: 37 },
    { key: 'rfq_open', count: 12 },
    { key: 'awaiting_appr', count: 8 },
    { key: 'po_issued', count: 64 },
    { key: 'in_transit', count: 41 },
    { key: 'three_way', count: 28 },
  ],

  // Sparkline for Total spend (12 mo, IDR millions)
  spendTrend: [3100, 3280, 2960, 3540, 3610, 3480, 3720, 3820, 3640, 3550, 3490, 3720],

  // Spend by category
  categories: [
    { name: 'Packaging & Labels', idr: 8_420_000_000, share: 19.9, color: 'oklch(0.46 0.14 254)' },
    { name: 'Private Label Goods', idr: 7_120_000_000, share: 16.8, color: 'oklch(0.58 0.13 220)' },
    { name: 'Logistics & Freight', idr: 6_340_000_000, share: 15.0, color: 'oklch(0.62 0.12 195)' },
    { name: 'IT & Software', idr: 4_910_000_000, share: 11.6, color: 'oklch(0.68 0.10 170)' },
    { name: 'Store Maintenance', idr: 3_870_000_000, share: 9.1, color: 'oklch(0.72 0.09 140)' },
    { name: 'Marketing & Promo', idr: 3_240_000_000, share: 7.7, color: 'oklch(0.76 0.10 90)' },
    { name: 'Utilities & Energy', idr: 2_980_000_000, share: 7.0, color: 'oklch(0.78 0.11 60)' },
    { name: 'Professional Services', idr: 2_150_000_000, share: 5.1, color: 'oklch(0.72 0.13 30)' },
    { name: 'Office & Admin', idr: 1_840_000_000, share: 4.3, color: 'oklch(0.68 0.10 5)' },
    { name: 'Other', idr: 1_480_000_000, share: 3.5, color: 'oklch(0.70 0.05 280)' },
  ],

  businessUnits: [
    { name: 'Retail Ops — West', idr: 14_820_000_000 },
    { name: 'Retail Ops — East', idr: 11_130_000_000 },
    { name: 'Warehouse & DC', idr: 7_920_000_000 },
    { name: 'HQ & Corporate', idr: 4_280_000_000 },
    { name: 'E-commerce', idr: 2_640_000_000 },
    { name: 'New format (Mini)', idr: 1_560_000_000 },
  ],

  topVendors: [
    { name: 'PT Kemasan Jaya Abadi', cat: 'Packaging', idr: 3_280_000_000, otif: 96, risk: 'low' },
    { name: 'CV Logistik Nusantara', cat: 'Logistics', idr: 2_910_000_000, otif: 91, risk: 'med' },
    { name: 'PT Sumber Pangan Mandiri', cat: 'Private Label', idr: 2_640_000_000, otif: 88, risk: 'low' },
    { name: 'PT Indoprint Solusi', cat: 'Packaging', idr: 1_890_000_000, otif: 82, risk: 'med' },
    { name: 'PT Cahaya Digital Tech', cat: 'IT', idr: 1_720_000_000, otif: 98, risk: 'low' },
    { name: 'PT Gudang Prima', cat: 'Maintenance', idr: 1_540_000_000, otif: 79, risk: 'high' },
    { name: 'CV Promo Kreatif', cat: 'Marketing', idr: 1_380_000_000, otif: 93, risk: 'low' },
    { name: 'PT Energi Terang', cat: 'Utilities', idr: 1_240_000_000, otif: 99, risk: 'low' },
    { name: 'PT Bahan Baku Sejati', cat: 'Private Label', idr: 1_120_000_000, otif: 85, risk: 'med' },
    { name: 'PT Kirim Cepat Express', cat: 'Logistics', idr: 980_000_000, otif: 88, risk: 'med' },
  ],

  // RFQ detail
  rfq: {
    id: 'RFQ-2026-0184',
    title: 'Packaging & store supplies — Q2 refill',
    requester: 'Rini Hartono · Retail Ops',
    budget: 1_850_000_000,
    lineItems: 34,
    closes: '22 Apr 2026',
    items: [
      { sku: 'PCK-BAG-L', name: 'Shopping bag L (kraft)', qty: 480_000 },
      { sku: 'PCK-BAG-M', name: 'Shopping bag M (kraft)', qty: 620_000 },
      { sku: 'PCK-WRAP', name: 'Produce wrap film 45cm', qty: 2_400 },
      { sku: 'LBL-PRC', name: 'Price label roll', qty: 18_000 },
      { sku: 'PCK-BOX-S', name: 'Corrugated box S', qty: 92_000 },
    ],
    bidders: [
      {
        name: 'PT Kemasan Jaya Abadi',
        price: 1_712_000_000,
        lead: 14,
        quality: 4.6,
        otif: 96,
        paymentTerms: 'NET 45',
        risk: 'Low',
        aiScore: 92,
        aiPick: true,
        notes: 'Strong 3-yr history. FSC certified. Bundle discount 4.2% vs prior award.',
      },
      {
        name: 'PT Indoprint Solusi',
        price: 1_648_000_000,
        lead: 21,
        quality: 4.1,
        otif: 82,
        paymentTerms: 'NET 30',
        risk: 'Medium',
        aiScore: 78,
        tagLowest: true,
        notes: 'Lowest price but OTIF 14pt below category benchmark.',
      },
      {
        name: 'CV Grafika Mandiri',
        price: 1_789_000_000,
        lead: 10,
        quality: 4.4,
        otif: 94,
        paymentTerms: 'NET 30',
        risk: 'Low',
        aiScore: 85,
        tagFastest: true,
        notes: 'Fastest lead time. Capacity limit at ±30% of RFQ volume.',
      },
      {
        name: 'PT Prima Pack Indonesia',
        price: 1_834_000_000,
        lead: 17,
        quality: 4.7,
        otif: 91,
        paymentTerms: 'NET 60',
        risk: 'Low',
        aiScore: 88,
        tagQuality: true,
        notes: 'Best quality scores. Price 7.1% above median — weak on price.',
      },
    ],
  },

  // Savings opportunities
  savings: [
    {
      title: 'Consolidate 4 packaging vendors → 2',
      lever: 'lever_consolidation',
      potential: 640_000_000,
      confidence: 88,
      effort: 'Medium',
      impact: 'High',
      detail: 'Cluster analysis finds 4 vendors (Kemasan Jaya, Indoprint, Grafika Mandiri, Prima Pack) serve overlapping SKU footprints. Combined volume unlocks tier-2 discount.',
    },
    {
      title: 'Renegotiate logistics rate card (DC → outlet)',
      lever: 'lever_negotiation',
      potential: 480_000_000,
      confidence: 82,
      effort: 'Low',
      impact: 'High',
      detail: 'Logistik Nusantara rate card unchanged for 22 months. Market benchmark -9.4% on last-mile Jabodetabek lanes.',
    },
    {
      title: 'Substitute branded cleaning supplies with private label',
      lever: 'lever_substitution',
      potential: 215_000_000,
      confidence: 76,
      effort: 'Low',
      impact: 'Medium',
      detail: 'AI matched 38 SKUs with equivalent private-label alternatives at 18–24% lower unit price.',
    },
    {
      title: 'Rationalize tail spend — 61 vendors < Rp 50 jt/yr',
      lever: 'lever_tail',
      potential: 190_000_000,
      confidence: 71,
      effort: 'High',
      impact: 'Medium',
      detail: 'Consolidate to preferred vendors. Cuts admin cost + unlocks catalog discounts.',
    },
    {
      title: 'Extend payment terms NET 30 → NET 45',
      lever: 'lever_payment',
      potential: 312_000_000,
      confidence: 65,
      effort: 'Medium',
      impact: 'High',
      detail: 'Working capital lever. 11 top vendors within negotiation appetite per market signals.',
    },
    {
      title: 'Sourcing wave — private label ingredients',
      lever: 'lever_negotiation',
      potential: 158_000_000,
      confidence: 79,
      effort: 'Medium',
      impact: 'Medium',
      detail: 'Competitive RFQ on 12 ingredient SKUs suggested by benchmark gap vs. FMCG index.',
    },
  ],

  // Categorization — low confidence rows
  categoryTriage: [
    { desc: 'Cetak banner promo "Lebaran 2026" — vendor CV Promo Kreatif', amount: 42_800_000, suggested: 'Marketing › Print collateral', conf: 68 },
    { desc: 'Service AC split 2PK — 12 unit outlet BSD', amount: 18_500_000, suggested: 'Store Maintenance › HVAC service', conf: 54 },
    { desc: 'Subscription Azure cloud compute Q1', amount: 27_200_000, suggested: 'IT & Software › Cloud infra', conf: 91 },
    { desc: 'Pallet kayu heavy-duty 120x100', amount: 9_400_000, suggested: 'Packaging › Pallets', conf: 76 },
    { desc: 'Jasa audit keuangan eksternal KAP', amount: 115_000_000, suggested: 'Professional Services › Audit', conf: 94 },
    { desc: 'Seragam staff kasir — 240 pcs', amount: 31_200_000, suggested: 'Store Maintenance › Uniforms', conf: 58 },
    { desc: 'Kopi & teh pantry HQ bulanan', amount: 4_200_000, suggested: 'Office & Admin › Pantry', conf: 82 },
  ],

  // KPI / governance scorecard
  scorecard: [
    { name: 'PR-to-PO cycle time', target: '≤ 7 days', actual: '6.4 days', status: 'pos', delta: '-0.9d' },
    { name: 'PO compliance', target: '≥ 90%', actual: '87.5%', status: 'warn', delta: '-2.1pp' },
    { name: 'Policy violations', target: '≤ 1.0%', actual: '0.6%', status: 'pos', delta: '-0.3pp' },
    { name: 'Savings realization', target: 'Rp 2.5 M', actual: 'Rp 2.84 M', status: 'pos', delta: '+13.6%' },
    { name: '3-way match rate', target: '≥ 95%', actual: '92.1%', status: 'warn', delta: '-1.4pp' },
    { name: 'Vendor OTIF', target: '≥ 92%', actual: '94.2%', status: 'pos', delta: '+1.8pp' },
    { name: 'Single-source spend', target: '≤ 30%', actual: '34.8%', status: 'neg', delta: '+4.8pp' },
    { name: 'Maverick spend', target: '≤ 5%', actual: '6.9%', status: 'warn', delta: '+0.4pp' },
  ],

  policyBreaches: [
    { id: 'PO-2026-04-0221', who: 'Budi S.', what: 'Split PO to avoid Rp 100 jt threshold', severity: 'high', when: '2d ago' },
    { id: 'PO-2026-04-0198', who: 'Lia M.', what: 'Single-source without justification', severity: 'med', when: '3d ago' },
    { id: 'PO-2026-04-0164', who: 'Ardi P.', what: 'After-the-fact PO issued', severity: 'med', when: '5d ago' },
    { id: 'PO-2026-04-0139', who: 'Kirana W.', what: 'Vendor not in approved list', severity: 'low', when: '6d ago' },
  ],

  recentActivity: [
    { who: 'AI Copilot', what: 'Flagged 3 duplicate invoices from PT Indoprint Solusi', when: '14 min ago', kind: 'ai' },
    { who: 'Maya K.', what: 'Approved PO-2026-04-0318 · Rp 284 jt', when: '1h ago', kind: 'approve' },
    { who: 'AI Copilot', what: 'Categorized 142 line items into IT & Software', when: '2h ago', kind: 'ai' },
    { who: 'Rini H.', what: 'Opened RFQ-2026-0184 · Packaging refill', when: '4h ago', kind: 'rfq' },
    { who: 'AI Copilot', what: 'Detected price drift on Logistics rate card', when: 'Yesterday', kind: 'ai' },
    { who: 'Deni A.', what: 'Vendor PT Gudang Prima flagged — OTIF below threshold', when: 'Yesterday', kind: 'risk' },
  ],

  aiInsights: [
    {
      title: 'Savings lever: consolidate packaging vendors',
      body: 'Merging 4 overlapping vendors into 2 unlocks tier-2 discount ≈ Rp 640 jt.',
      tag: 'High impact',
      tagType: 'pos',
    },
    {
      title: 'Risk: PT Gudang Prima OTIF trending down',
      body: 'OTIF 79% (↓7pp QoQ). Consider dual-sourcing maintenance for East region.',
      tag: 'Vendor risk',
      tagType: 'neg',
    },
    {
      title: 'Compliance: single-source drift',
      body: 'Single-source share +4.8pp vs policy cap. Top offenders concentrated in HQ BU.',
      tag: 'Policy',
      tagType: 'warn',
    },
  ],

  // Heatmap — vendor OTIF by month (4 vendors × 12 months)
  heatmap: {
    rows: ['Kemasan Jaya', 'Logistik Nusantara', 'Sumber Pangan', 'Indoprint', 'Cahaya Digital', 'Gudang Prima'],
    months: ['Mei', 'Jun', 'Jul', 'Agu', 'Sep', 'Okt', 'Nov', 'Des', 'Jan', 'Feb', 'Mar', 'Apr'],
    // values 0..100 OTIF
    values: [
      [95, 97, 94, 96, 95, 97, 98, 96, 95, 97, 96, 96],
      [88, 89, 91, 92, 90, 91, 93, 92, 90, 91, 92, 91],
      [85, 87, 86, 88, 89, 90, 88, 89, 88, 87, 88, 88],
      [84, 83, 82, 85, 84, 82, 80, 81, 82, 83, 82, 82],
      [97, 98, 99, 98, 98, 99, 98, 98, 97, 98, 98, 98],
      [86, 85, 84, 82, 81, 80, 78, 77, 78, 79, 79, 79],
    ],
  },

  // Monthly cycle time
  cycleTrend: [8.2, 8.0, 7.8, 7.6, 7.4, 7.2, 7.1, 7.0, 6.9, 6.7, 6.5, 6.4],
  savingsTrend: [120, 180, 160, 210, 240, 260, 280, 290, 300, 310, 290, 320], // IDR M
};

// My Work inbox
DATA.inbox = [
  { id: 'PO-2026-04-0318', type: 'approval', title: 'Approve PO — Packaging refill Q2', vendor: 'PT Kemasan Jaya Abadi', amount: 1_712_000_000, who: 'Rini Hartono', when: '2h ago', sla: 'Due today', slaTone: 'warn', priority: 'high', aiNote: 'Within budget. AI recommends: approve.' },
  { id: 'RFQ-2026-0184', type: 'award', title: 'Award RFQ — 4 bidders ready', vendor: '4 bidders · Packaging', amount: 1_712_000_000, who: 'Maya Handoko', when: '4h ago', sla: 'Closes 22 Apr', slaTone: '', priority: 'high', aiNote: 'AI recommends: PT Kemasan Jaya Abadi (92% confidence)' },
  { id: 'INV-10298', type: 'match', title: '3-way match exception — price variance', vendor: 'PT Indoprint Solusi', amount: 284_000_000, who: 'System', when: '6h ago', sla: 'Blocks payment', slaTone: 'neg', priority: 'high', aiNote: 'Unit price 8.2% above PO. Possible duplicate line.' },
  { id: 'VND-0042', type: 'onboard', title: 'New vendor onboarding — docs pending', vendor: 'CV Grafika Mandiri', amount: null, who: 'Ardi Pratama', when: '1d ago', sla: '3 days', slaTone: '', priority: 'med', aiNote: 'NPWP + Akta missing. Auto-email sent.' },
  { id: 'CTR-2205', type: 'contract', title: 'Contract renewal — Logistik Nusantara', vendor: 'CV Logistik Nusantara', amount: 2_910_000_000, who: 'Maya Handoko', when: '1d ago', sla: '28 days', slaTone: 'warn', priority: 'med', aiNote: 'Benchmark -9.4%. AI drafted negotiation points.' },
  { id: 'RSK-0012', type: 'risk', title: 'Vendor risk — OTIF dropped to 79%', vendor: 'PT Gudang Prima', amount: null, who: 'System', when: '2d ago', sla: 'Review', slaTone: '', priority: 'med', aiNote: 'Consider dual-sourcing maintenance East region.' },
  { id: 'PR-2026-04-0419', type: 'approval', title: 'Approve PR — IT laptops batch 3', vendor: 'PT Cahaya Digital Tech', amount: 186_000_000, who: 'Deni Arifin', when: '2d ago', sla: '5 days', slaTone: '', priority: 'low', aiNote: 'Unit price aligns with last quarter.' },
  { id: 'PO-2026-04-0221', type: 'policy', title: 'Policy breach — split PO suspected', vendor: 'PT Prima Pack Indonesia', amount: 99_400_000, who: 'Budi Santoso', when: '2d ago', sla: 'High', slaTone: 'neg', priority: 'high', aiNote: 'Same vendor 3x under Rp 100jt threshold.' },
];

// Vendor 360
DATA.vendor360 = {
  code: 'V-00142',
  name: 'PT Kemasan Jaya Abadi',
  category: 'Packaging & Labels',
  tier: 'Strategic',
  since: '2021',
  rating: 4.6,
  otif: 96,
  riskScore: 18, // out of 100 (lower = safer)
  address: 'Jl. Industri Raya III Blok AE No. 2, Cikupa, Tangerang',
  contact: 'Pak Hendro Wijaya · hendro@kemasanjaya.co.id · +62 812-8873-4221',
  taxId: 'NPWP 01.234.567.8-123.000',
  bank: 'BCA 389-0-xxxx-421',
  payTerms: 'NET 45',
  ytdSpend: 3_280_000_000,
  openPos: 8,
  openInvoices: 3,
  contracts: 2,
  risks: [
    { type: 'financial', label: 'Financial health', score: 88, tone: 'pos', note: 'Stable 3-yr filings, positive equity' },
    { type: 'delivery', label: 'Delivery reliability', score: 96, tone: 'pos', note: 'OTIF 96% last 12 mo' },
    { type: 'quality', label: 'Quality', score: 92, tone: 'pos', note: 'Defect rate 0.4%' },
    { type: 'compliance', label: 'Compliance', score: 81, tone: 'warn', note: 'SMK3 cert expires in 47 days' },
    { type: 'concentration', label: 'Spend concentration', score: 62, tone: 'warn', note: '38% of packaging spend here' },
  ],
  spendByMonth: [185, 198, 212, 245, 268, 281, 292, 301, 288, 295, 312, 303],
  activity: [
    { when: '2h ago', what: 'Quoted RFQ-2026-0184 — Rp 1.71 M', kind: 'rfq' },
    { when: '1d ago', what: 'Delivered PO-2026-04-0291 (complete, on time)', kind: 'delivery' },
    { when: '3d ago', what: 'Invoice INV-10281 paid — Rp 284 jt', kind: 'payment' },
    { when: '5d ago', what: 'PO-2026-04-0302 issued — Rp 147 jt', kind: 'po' },
    { when: '1w ago', what: 'Price book updated (kraft bag -2.1%)', kind: 'catalog' },
  ],
  pos: [
    { id: 'PO-2026-04-0318', date: '16 Apr', amount: 1_712_000_000, status: 'Awaiting approval' },
    { id: 'PO-2026-04-0291', date: '12 Apr', amount: 284_000_000, status: 'Delivered' },
    { id: 'PO-2026-04-0268', date: '8 Apr', amount: 147_000_000, status: 'In transit' },
    { id: 'PO-2026-03-0214', date: '29 Mar', amount: 398_000_000, status: 'Closed' },
  ],
};

// AI Agents
DATA.agents = [
  { id: 'sourcing', name: 'Sourcing Agent', emoji: 'S', color: 'var(--brand)', status: 'Working', task: 'Drafting RFQ for Q3 private-label ingredients', progress: 64, items: 12, last: '3 min ago', desc: 'Composes RFQs, shortlists vendors from history + market.' },
  { id: 'negotiation', name: 'Negotiation Agent', emoji: 'N', color: 'oklch(0.62 0.13 195)', status: 'Ready', task: 'Benchmarking Logistik Nusantara rate card', progress: 100, items: 3, last: '12 min ago', desc: 'Analyzes quotes vs market, drafts counter-offers.' },
  { id: 'compliance', name: 'Compliance Agent', emoji: 'C', color: 'oklch(0.70 0.13 30)', status: 'Alert', task: 'Detected 1 split-PO pattern · 2 single-source breaches', progress: 100, items: 4, last: 'just now', desc: 'Watches PO flow, flags policy breaches in real-time.' },
  { id: 'categorization', name: 'Categorization Agent', emoji: 'K', color: 'oklch(0.68 0.12 160)', status: 'Working', task: 'Classifying 142 new line items into UNSPSC', progress: 82, items: 142, last: '1 min ago', desc: 'Auto-tags line items, flags low-confidence for review.' },
  { id: 'invoice', name: 'Invoice Agent', emoji: 'I', color: 'oklch(0.72 0.10 90)', status: 'Ready', task: 'All invoices matched. 3 exceptions pending review.', progress: 100, items: 28, last: '8 min ago', desc: 'Performs 3-way match, flags price/quantity variance.' },
  { id: 'market', name: 'Market Agent', emoji: 'M', color: 'oklch(0.62 0.12 280)', status: 'Working', task: 'Tracking 12 commodity prices · kraft pulp +1.2%', progress: 45, items: 12, last: '20 min ago', desc: 'Tracks external benchmarks, feeds negotiation & savings.' },
];

// Create RFQ — AI suggestions
DATA.rfqWizard = {
  suggestedVendors: [
    { name: 'PT Kemasan Jaya Abadi', otif: 96, lastPrice: 1_628_000_000, tag: 'Strategic' },
    { name: 'PT Indoprint Solusi', otif: 82, lastPrice: 1_598_000_000, tag: 'Preferred' },
    { name: 'CV Grafika Mandiri', otif: 94, lastPrice: 1_742_000_000, tag: 'Preferred' },
    { name: 'PT Prima Pack Indonesia', otif: 91, lastPrice: 1_810_000_000, tag: 'Qualified' },
    { name: 'PT Sinar Pack Utama', otif: 88, lastPrice: null, tag: 'New match' },
  ],
};

window.DATA = DATA;
