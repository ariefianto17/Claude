// Minimal stroke-based icon set — no heavy SVG hand-drawing
const Ic = ({ d, size = 18, stroke = 1.75, fill = 'none' }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill={fill} stroke="currentColor"
       strokeWidth={stroke} strokeLinecap="round" strokeLinejoin="round" className="ic">
    {d}
  </svg>
);

const Icons = {
  dashboard: <Ic d={<><rect x="3" y="3" width="7" height="9"/><rect x="14" y="3" width="7" height="5"/><rect x="14" y="12" width="7" height="9"/><rect x="3" y="16" width="7" height="5"/></>} />,
  sourcing: <Ic d={<><path d="M3 7h18"/><path d="M6 7V5a2 2 0 0 1 2-2h8a2 2 0 0 1 2 2v2"/><rect x="3" y="7" width="18" height="14" rx="2"/><path d="M9 12h6"/></>} />,
  orders: <Ic d={<><path d="M3 3h2l2.5 12a2 2 0 0 0 2 1.6h8a2 2 0 0 0 2-1.6L21 7H6"/><circle cx="9" cy="20" r="1.5"/><circle cx="18" cy="20" r="1.5"/></>} />,
  vendors: <Ic d={<><circle cx="9" cy="8" r="3"/><path d="M3 20c0-3.3 2.7-6 6-6s6 2.7 6 6"/><circle cx="17" cy="6" r="2.5"/><path d="M15 14c3 0 6 1.8 6 5"/></>} />,
  contracts: <Ic d={<><path d="M14 3H6a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V9z"/><path d="M14 3v6h6"/><path d="M8 14h8"/><path d="M8 18h5"/></>} />,
  spend: <Ic d={<><path d="M3 3v18h18"/><path d="M7 15l4-5 3 3 6-7"/></>} />,
  categorize: <Ic d={<><rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/><rect x="3" y="14" width="7" height="7" rx="1"/><path d="M14 14l7 7M21 14l-7 7"/></>} />,
  savings: <Ic d={<><path d="M12 2v2M12 20v2M4.2 4.2l1.4 1.4M18.4 18.4l1.4 1.4M2 12h2M20 12h2M4.2 19.8l1.4-1.4M18.4 5.6l1.4-1.4"/><circle cx="12" cy="12" r="5"/></>} />,
  kpi: <Ic d={<><path d="M3 20h18"/><rect x="5" y="10" width="3" height="10"/><rect x="10.5" y="6" width="3" height="14"/><rect x="16" y="13" width="3" height="7"/></>} />,
  governance: <Ic d={<><path d="M12 3l8 3v6c0 4.5-3.5 8-8 9-4.5-1-8-4.5-8-9V6z"/><path d="M9 12l2 2 4-4"/></>} />,
  settings: <Ic d={<><circle cx="12" cy="12" r="3"/><path d="M19 12a7 7 0 0 0-.1-1.2l2-1.5-2-3.5-2.3.9a7 7 0 0 0-2-1.2l-.4-2.5h-4l-.4 2.5a7 7 0 0 0-2 1.2l-2.3-.9-2 3.5 2 1.5A7 7 0 0 0 5 12c0 .4 0 .8.1 1.2l-2 1.5 2 3.5 2.3-.9c.6.5 1.3.9 2 1.2l.4 2.5h4l.4-2.5a7 7 0 0 0 2-1.2l2.3.9 2-3.5-2-1.5c.1-.4.1-.8.1-1.2z"/></>} />,
  search: <Ic d={<><circle cx="11" cy="11" r="7"/><path d="M21 21l-4.3-4.3"/></>} />,
  bell: <Ic d={<><path d="M6 8a6 6 0 1 1 12 0c0 5 3 6 3 6H3s3-1 3-6"/><path d="M10 19a2 2 0 0 0 4 0"/></>} />,
  sparkle: <Ic d={<><path d="M12 3l1.8 5.2L19 10l-5.2 1.8L12 17l-1.8-5.2L5 10l5.2-1.8z"/><path d="M19 16l.7 1.8L21.5 18.5 19.7 19.3 19 21l-.7-1.7L16.5 18.5l1.8-.7z"/></>} />,
  chevron: <Ic d={<path d="M9 18l6-6-6-6"/>} />,
  chevronDown: <Ic d={<path d="M6 9l6 6 6-6"/>} />,
  plus: <Ic d={<><path d="M12 5v14M5 12h14"/></>} />,
  inbox: <Ic d={<><path d="M3 12l4-8h10l4 8v7a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/><path d="M3 12h5l2 3h4l2-3h5"/></>} />,
  agent: <Ic d={<><rect x="4" y="8" width="16" height="12" rx="3"/><path d="M9 14h.01M15 14h.01"/><path d="M12 4v4M8 4h8"/></>} />,
  cmd: <Ic d={<><path d="M9 6a3 3 0 1 0-3 3h12a3 3 0 1 0-3-3v12a3 3 0 1 0 3-3H6a3 3 0 1 0 3 3z"/></>} />,
  help: <Ic d={<><circle cx="12" cy="12" r="9"/><path d="M9.5 9a2.5 2.5 0 1 1 3.5 2.3c-1 .5-1 1.2-1 2M12 17v.01"/></>} />,
  wand: <Ic d={<><path d="M3 21L14 10"/><path d="M17 4l2 2M21 8l-2-2M17 8l-4-4M21 4l-3 3"/></>} />,
  filter: <Ic d={<path d="M3 5h18l-7 9v6l-4-2v-4z"/>} />,
  download: <Ic d={<><path d="M12 3v12"/><path d="M7 10l5 5 5-5"/><path d="M4 21h16"/></>} />,
  more: <Ic d={<><circle cx="5" cy="12" r="1"/><circle cx="12" cy="12" r="1"/><circle cx="19" cy="12" r="1"/></>} />,
  close: <Ic d={<><path d="M6 6l12 12M18 6l-12 12"/></>} />,
  send: <Ic d={<><path d="M22 2L11 13"/><path d="M22 2l-7 20-4-9-9-4z"/></>} />,
  moon: <Ic d={<path d="M21 12.8A9 9 0 1 1 11.2 3a7 7 0 0 0 9.8 9.8z"/>} />,
  sun: <Ic d={<><circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M4.2 4.2l1.4 1.4M18.4 18.4l1.4 1.4M2 12h2M20 12h2M4.2 19.8l1.4-1.4M18.4 5.6l1.4-1.4"/></>} />,
  check: <Ic d={<path d="M4 12l5 5L20 6"/>} />,
  arrowUp: <Ic d={<><path d="M12 19V5"/><path d="M5 12l7-7 7 7"/></>} />,
  arrowDown: <Ic d={<><path d="M12 5v14"/><path d="M5 12l7 7 7-7"/></>} />,
  alert: <Ic d={<><path d="M12 3L2 21h20z"/><path d="M12 10v5M12 18.5v.5"/></>} />,
  clock: <Ic d={<><circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/></>} />,
  shield: <Ic d={<path d="M12 3l8 3v6c0 4.5-3.5 8-8 9-4.5-1-8-4.5-8-9V6z"/>} />,
  info: <Ic d={<><circle cx="12" cy="12" r="9"/><path d="M12 8v.01M11 12h1v5h1"/></>} />,
  flag: <Ic d={<><path d="M4 21V4h11l-1.5 4 1.5 4H4"/></>} />,
  building: <Ic d={<><rect x="4" y="4" width="16" height="16" rx="1"/><path d="M9 9h.01M9 13h.01M9 17h.01M15 9h.01M15 13h.01M15 17h.01"/></>} />,
  truck: <Ic d={<><path d="M3 6h11v10H3z"/><path d="M14 9h4l3 3v4h-7"/><circle cx="7" cy="18" r="2"/><circle cx="17" cy="18" r="2"/></>} />,
};

window.Icons = Icons;
